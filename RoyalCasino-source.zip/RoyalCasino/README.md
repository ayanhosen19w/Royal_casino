# RoyalCasino — auto-building casino for Paper

Type `/casino`, get a golden block, place it, and a full casino rises out of the ground layer by layer with
sounds, particles and fireworks. Players spend **chips** (added by admins) on five games with win effects.

Tested design target: **Paper 1.21.x, Java 21**. (Paper only — not Spigot/Folia.)

## Install

1. Install JDK 21 and Maven, then in this folder run: `mvn package`
2. Copy `target/RoyalCasino.jar` into your server's `plugins/` folder and restart.
3. If your server isn't 1.21.4, change `<paper.version>` in `pom.xml` to match (any 1.21.x works), then rebuild.

## Building a casino

* `/casino` — gives you the **Royal Casino Builder** block (admins/ops).
* Stand where the entrance should be, look in the direction the casino should extend, and **place the block**.
  The block is the middle of the entrance plaza; the casino grows away from you (33 x 34 blocks, 11 tall).
* It clears the area it needs, lays a foundation down to solid ground, builds, and spawns the click-targets
  and floating signs. Anyone standing in the footprint is moved out first.
* Inside: **5 slot machines**, **roulette**, **blackjack**, **lucky dice**, **coin flip**, a **cashier** desk,
  plus a fountain, lounge bar, chandeliers and a glass skylight.
* Walk up to any table/machine and **right-click** it to play.

## Chips and admins

Chips are virtual (saved in `plugins/RoyalCasino/balances.yml`). Nobody can get chips from the casino itself,
admins hand them out:

| Command | What it does | Permission |
|---|---|---|
| `/chips` | your balance | everyone |
| `/chips top` | leaderboard | everyone |
| `/chips pay <player> <amount>` | send chips (off by default, `economy.allow-player-pay`) | everyone |
| `/chips add <player> <amount>` | give chips (`10k`, `2.5m`, `1b` work) | `royalcasino.admin` |
| `/chips remove <player> <amount>` | take chips | `royalcasino.admin` |
| `/chips set <player> <amount>` / `reset <player>` / `check <player>` | | `royalcasino.admin` |
| `/casino` / `/casino give <player>` | get the builder block | `royalcasino.build` |
| `/casino list` | list built casinos | `royalcasino.build` |
| `/casino remove` then `/casino remove confirm` | demolish the casino you're standing in | `royalcasino.admin` |
| `/casino reload` | reload `config.yml` | `royalcasino.admin` |

Permissions: `royalcasino.play` (default: everyone), `royalcasino.build` and `royalcasino.admin` (default: op).
Give them to your staff group with LuckPerms or similar. Players must have joined once before you can add chips to them.

## The games

| Game | How it plays | Return to player |
|---|---|---|
| Slots | 3 reels, middle row pays. Progressive jackpot for 3 Lucky Stars (min bet in config) | ~93% (incl. 2% to the jackpot) |
| Roulette | European single zero. Red/Black, Odd/Even, 1-18/19-36, dozens, straight number; scrolling wheel | 97.3% |
| Blackjack | vs dealer, blackjack pays 3:2, double down, dealer stands on 17 (no split/insurance) | ~99% with good play |
| Lucky Dice | two dice: Under 7 / Exactly 7 / Over 7 | 95-95.8% |
| Coin Flip | heads or tails | 97.5% |

Closing a game mid-round never loses chips unfairly: the round settles instantly (blackjack auto-stands).
Big wins trigger titles, fireworks and a server broadcast (`effects.big-win-broadcast`).

Everything is tunable in `plugins/RoyalCasino/config.yml` (casino name on the sign, bet sizes, payouts, jackpot, effects, build speed).

## Notes

* The casino is protected: non-admins can't break/place blocks inside, explosions don't damage it, no mob spawns.
  It doesn't hook into WorldGuard/claim plugins; choose a spot that suits your server rules.
* Entities (click boxes + signs) are tagged to their casino, so `/casino remove` cleans them up.
* Data files: `balances.yml` (chips + jackpot), `casinos.yml` (where casinos are).

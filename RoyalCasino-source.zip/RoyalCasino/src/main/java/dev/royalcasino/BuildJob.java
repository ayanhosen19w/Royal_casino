package dev.royalcasino;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Bisected;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.type.Lantern;
import org.bukkit.block.data.type.Slab;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.concurrent.ThreadLocalRandom;

/** Builds one casino, layer by layer, with effects. Also knows how to demolish one. */
final class BuildJob {
    private static final int MAX_FOUNDATION = 24;

    private final RoyalCasino plugin;
    private final Frame frame;
    private final CasinoPlan plan;
    private final Player builder;
    private final String id;
    private final int[][] depth = new int[CasinoPlan.W][CasinoPlan.D];  // foundation depth per column
    private int lowestY;       // lowest world y we will touch
    private int nextY;         // next world y to process
    private int topY;          // last world y to process
    private BukkitTask task;
    private boolean done;
    private CasinoRegion region;

    private BuildJob(RoyalCasino plugin, Frame frame, Player builder) {
        this.plugin = plugin;
        this.frame = frame;
        this.builder = builder;
        this.plan = new CasinoPlan(plugin.getConfig().getString("casino-name", "ROYAL CASINO"));
        this.id = "c" + Long.toString(System.currentTimeMillis(), 36);
    }

    /**
     * Validates and starts a build. Returns null on success or a MiniMessage error text on failure.
     *
     * @param floorY world y of the casino floor (the block below where the builder block was placed)
     */
    static String start(RoyalCasino plugin, Player builder, World w, int x, int floorY, int z, BlockFace forward) {
        Frame f = Frame.of(w, x, floorY, z, forward);

        if (floorY - 3 < w.getMinHeight() || floorY + CasinoPlan.H + 2 > w.getMaxHeight()) {
            return "<red>There is not enough vertical space here for a casino.";
        }
        int[] bb = bounds(f);
        if (plugin.regions().overlaps(w.getName(), bb[0], floorY - MAX_FOUNDATION, bb[1], bb[2], floorY + CasinoPlan.H, bb[3])) {
            return "<red>This overlaps another casino. Move further away.";
        }

        BuildJob job = new BuildJob(plugin, f, builder);
        job.scanFoundation();
        job.begin();
        return null;
    }

    /** {minX, minZ, maxX, maxZ} of the footprint. */
    private static int[] bounds(Frame f) {
        int[] xs = {f.wx(0, 0), f.wx(CasinoPlan.W - 1, 0), f.wx(0, CasinoPlan.D - 1), f.wx(CasinoPlan.W - 1, CasinoPlan.D - 1)};
        int[] zs = {f.wz(0, 0), f.wz(CasinoPlan.W - 1, 0), f.wz(0, CasinoPlan.D - 1), f.wz(CasinoPlan.W - 1, CasinoPlan.D - 1)};
        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, minZ = Integer.MAX_VALUE, maxZ = Integer.MIN_VALUE;
        for (int v : xs) { minX = Math.min(minX, v); maxX = Math.max(maxX, v); }
        for (int v : zs) { minZ = Math.min(minZ, v); maxZ = Math.max(maxZ, v); }
        return new int[]{minX, minZ, maxX, maxZ};
    }

    private static boolean soft(Block b) {
        Material m = b.getType();
        return b.isEmpty() || b.isLiquid() || b.isPassable() || b.isReplaceable()
                || leavesOrLog(m);
    }

    private static boolean leavesOrLog(Material m) {
        String n = m.name();
        return n.endsWith("_LEAVES") || n.endsWith("_LOG") || n.endsWith("_WOOD");
    }

    /** How deep must the foundation go under each column so the casino never floats? */
    private void scanFoundation() {
        World w = frame.world();
        int minH = w.getMinHeight();
        int deepest = 1;
        for (int x = 0; x < CasinoPlan.W; x++) {
            for (int z = 0; z < CasinoPlan.D; z++) {
                int wx = frame.wx(x, z), wz = frame.wz(x, z);
                int count = 0;
                int y = frame.oy() - 1;
                while (count < MAX_FOUNDATION && y > minH && soft(w.getBlockAt(wx, y, wz))) {
                    count++;
                    y--;
                }
                depth[x][z] = Math.min(MAX_FOUNDATION, count + 1);
                deepest = Math.max(deepest, depth[x][z]);
            }
        }
        lowestY = frame.oy() - deepest;
        topY = frame.oy() + CasinoPlan.H - 1;
    }

    private void begin() {
        World w = frame.world();
        int[] bb = bounds(frame);
        region = new CasinoRegion(id, w.getName(), bb[0], lowestY, bb[1], bb[2], topY + 1, bb[3], frame.oy());
        plugin.regions().add(region);
        plugin.jobs().add(this);

        // Move anyone standing in the footprint out to the street.
        Location out = frame.loc(CasinoPlan.CX + 0.5, frame.oy() + 1.0, -3.0);
        out.setDirection(new org.bukkit.util.Vector(frame.fx(), 0, frame.fz()));
        for (Player p : w.getPlayers()) {
            if (region.contains(p.getLocation())) p.teleport(out);
        }

        Util.msg(builder, "<gold>Building your casino... <gray>stand back and enjoy the show!");
        w.playSound(frame.loc(CasinoPlan.CX + 0.5, frame.oy() + 1.0, 0), Sound.BLOCK_BEACON_ACTIVATE, 2f, 0.8f);

        nextY = lowestY;
        long ticks = Math.max(1L, plugin.getConfig().getLong("build.layer-ticks", 3L));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 2L, ticks);
    }

    private void tick() {
        if (nextY > topY) {
            finish();
            return;
        }
        placeLayer(nextY);
        effects(nextY);
        nextY++;
        if (nextY > topY) finish();
    }

    /** Completes everything immediately (used on server shutdown). */
    void finishNow() {
        if (done) return;
        while (nextY <= topY) placeLayer(nextY++);
        finish();
    }

    private void placeLayer(int wy) {
        World w = frame.world();
        int ly = wy - frame.oy();
        for (int z = 0; z < CasinoPlan.D; z++) {
            for (int x = 0; x < CasinoPlan.W; x++) {
                Block b = w.getBlockAt(frame.wx(x, z), wy, frame.wz(x, z));
                if (ly < 0) {
                    int d = frame.oy() - wy;
                    if (d <= depth[x][z]) {
                        b.setType(d == 1 ? Material.POLISHED_BLACKSTONE_BRICKS : Material.BLACKSTONE, false);
                    }
                } else {
                    CasinoPlan.Cell c = plan.at(ly, z, x);
                    if (c == null) {
                        if (!b.isEmpty()) b.setType(Material.AIR, false);
                    } else {
                        b.setBlockData(toData(c), false);
                    }
                }
            }
        }
    }

    private BlockData toData(CasinoPlan.Cell c) {
        BlockData bd = c.m().createBlockData();
        if (c.face() != null && bd instanceof Directional d) {
            BlockFace rotated = frame.rot(c.face());
            if (d.getFaces().contains(rotated)) d.setFacing(rotated);
        }
        if (c.top()) {
            if (bd instanceof Slab s) s.setType(Slab.Type.TOP);
            else if (bd instanceof org.bukkit.block.data.type.Stairs st) st.setHalf(Bisected.Half.TOP);
            else if (bd instanceof Lantern l) l.setHanging(true);
        }
        return bd;
    }

    private void effects(int wy) {
        World w = frame.world();
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int i = 0; i < 10; i++) {
            Location l = frame.loc(r.nextDouble(1, CasinoPlan.W - 1), wy + 1.0, r.nextDouble(1, CasinoPlan.D - 1));
            // loc() uses y as given (we pass absolute world y)
            w.spawnParticle(Particle.END_ROD, l, 2, 0.2, 0.2, 0.2, 0.02);
        }
        float progress = (wy - lowestY) / (float) Math.max(1, topY - lowestY);
        Location c = frame.loc(CasinoPlan.CX + 0.5, wy + 1.0, CasinoPlan.D / 2.0);
        w.playSound(c, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 2.0f, 0.5f + 1.5f * progress);
        if ((wy & 1) == 0) w.playSound(c, Sound.BLOCK_STONE_PLACE, 1.5f, 0.8f);
    }

    private void finish() {
        if (done) return;
        done = true;
        if (task != null) task.cancel();
        plugin.jobs().remove(this);

        World w = frame.world();
        double y0 = frame.oy();

        // stations (invisible click targets) + floating labels
        for (CasinoPlan.Station s : plan.stations) {
            Location l = frame.loc(s.x(), y0 + s.y(), s.z());
            w.spawn(l, Interaction.class, e -> {
                e.setInteractionWidth(s.w());
                e.setInteractionHeight(s.h());
                e.getPersistentDataContainer().set(plugin.keyGame(), PersistentDataType.STRING, s.type().key);
                e.getPersistentDataContainer().set(plugin.keyRegion(), PersistentDataType.STRING, id);
            });
        }
        for (CasinoPlan.Label lb : plan.labels) {
            Location l = frame.loc(lb.x(), y0 + lb.y(), lb.z());
            w.spawn(l, TextDisplay.class, t -> {
                t.text(label(lb.text()));
                t.setAlignment(TextDisplay.TextAlignment.CENTER);
                t.setShadowed(true);
                t.setSeeThrough(false);
                t.setLineWidth(lb.marquee() ? 600 : 200);
                if (lb.marquee()) {
                    t.setBillboard(Display.Billboard.VERTICAL);
                    t.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
                    float len = Math.max(6, plain(lb.text()).length());
                    float scale = Math.min(4.0f, 13.0f / (0.17f * len));
                    t.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(scale, scale, scale), new AxisAngle4f()));
                } else {
                    t.setBillboard(Display.Billboard.CENTER);
                    t.setBackgroundColor(Color.fromARGB(110, 0, 0, 0));
                    t.setViewRange(0.5f);
                }
                t.getPersistentDataContainer().set(plugin.keyRegion(), PersistentDataType.STRING, id);
            });
        }

        // grand opening
        Location door = frame.loc(CasinoPlan.CX + 0.5, y0 + 1.0, 1.0);
        w.playSound(door, Sound.UI_TOAST_CHALLENGE_COMPLETE, 3f, 1f);
        Fx.firework(frame.loc(CasinoPlan.CX - 6.0, y0 + 11.0, 2.0), Color.YELLOW, Color.ORANGE);
        Fx.firework(frame.loc(CasinoPlan.CX + 7.0, y0 + 11.0, 2.0), Color.FUCHSIA, Color.WHITE);
        Fx.firework(frame.loc(CasinoPlan.CX + 0.5, y0 + 13.0, 6.0), Color.AQUA, Color.YELLOW);

        if (plugin.getConfig().getBoolean("build.broadcast-opening", true)) {
            Bukkit.broadcast(Util.raw(Util.prefix + "<gold>★ A new casino has opened at <yellow>"
                    + frame.wx(CasinoPlan.CX, 0) + ", " + frame.oy() + ", " + frame.wz(CasinoPlan.CX, 0) + "</yellow>! ★"));
        }
        if (builder.isOnline()) {
            Util.msg(builder, "<green>Your casino is open! <gray>Admins add chips with <white>/chips add <player> <amount></white>.");
        }
    }

    private static Component label(String text) {
        return Util.raw(text);
    }

    private static String plain(String mm) {
        return mm.replaceAll("<[^>]*>", "");
    }

    // ------------------------------------------------------------------
    // Demolition
    // ------------------------------------------------------------------

    /** Removes the casino's stations/labels and clears its blocks layer by layer. */
    static void demolish(RoyalCasino plugin, CasinoRegion r) {
        World w = Bukkit.getWorld(r.world());
        if (w == null) {
            plugin.regions().remove(r.id());
            return;
        }
        // make sure the chunks are loaded so the entities can be found
        for (int cx = r.minX() >> 4; cx <= r.maxX() >> 4; cx++)
            for (int cz = r.minZ() >> 4; cz <= r.maxZ() >> 4; cz++) w.getChunkAt(cx, cz);

        BoundingBox box = new BoundingBox(r.minX(), r.minY(), r.minZ(), r.maxX() + 1, r.maxY() + 8, r.maxZ() + 1);
        for (Entity e : w.getNearbyEntities(box)) {
            String rid = e.getPersistentDataContainer().get(plugin.keyRegion(), PersistentDataType.STRING);
            if (r.id().equals(rid)) e.remove();
        }

        final int[] y = {r.maxY()};
        long ticks = Math.max(1L, plugin.getConfig().getLong("build.layer-ticks", 3L));
        new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                if (y[0] < r.minY()) {
                    plugin.regions().remove(r.id());
                    cancel();
                    return;
                }
                int wy = y[0]--;
                Material fill = wy > r.y0() ? Material.AIR : (wy == r.y0() ? Material.GRASS_BLOCK : Material.DIRT);
                for (int x = r.minX(); x <= r.maxX(); x++) {
                    for (int z = r.minZ(); z <= r.maxZ(); z++) {
                        Block b = w.getBlockAt(x, wy, z);
                        if (b.getType() != fill) b.setType(fill, false);
                    }
                }
                if (wy % 2 == 0) {
                    w.playSound(new Location(w, (r.minX() + r.maxX()) / 2.0, wy, (r.minZ() + r.maxZ()) / 2.0),
                            Sound.BLOCK_STONE_BREAK, 2f, 0.7f);
                }
            }
        }.runTaskTimer(plugin, 1L, ticks);
    }
}

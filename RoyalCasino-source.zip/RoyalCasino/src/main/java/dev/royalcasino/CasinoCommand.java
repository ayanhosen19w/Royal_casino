package dev.royalcasino;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/** /casino  - get the Casino Builder block (admins), plus give / list / remove / reload. */
final class CasinoCommand implements CommandExecutor, TabCompleter {
    private final RoyalCasino plugin;

    CasinoCommand(RoyalCasino plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);

        switch (sub) {
            case "" -> {
                if (!(sender instanceof Player p)) {
                    Util.msg(sender, "<red>Console: use <white>/casino give <player></white>.");
                    return true;
                }
                giveBuilder(p, p);
            }
            case "give" -> {
                if (args.length < 2) {
                    Util.msg(sender, "<gray>Usage: <white>/casino give <player>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    Util.msg(sender, "<red>That player is not online.");
                    return true;
                }
                giveBuilder(sender, target);
            }
            case "list" -> {
                if (plugin.regions().all().isEmpty()) {
                    Util.msg(sender, "<gray>No casinos have been built yet.");
                    return true;
                }
                Util.msg(sender, "<gold>Casinos:");
                for (CasinoRegion r : plugin.regions().all()) {
                    Util.msg(sender, "<gray> • <white>" + r.id() + " <gray>in <white>" + r.world() + " <gray>at <yellow>"
                            + (r.minX() + r.maxX()) / 2 + ", " + r.y0() + ", " + (r.minZ() + r.maxZ()) / 2);
                }
            }
            case "remove", "demolish" -> {
                if (!(sender instanceof Player p)) {
                    Util.msg(sender, "<red>Run this in-game while standing inside the casino.");
                    return true;
                }
                if (!p.hasPermission("royalcasino.admin")) {
                    Util.msg(sender, "<red>You don't have permission.");
                    return true;
                }
                CasinoRegion r = plugin.regions().at(p.getLocation());
                if (r == null) {
                    Util.msg(sender, "<red>Stand inside the casino you want to remove.");
                    return true;
                }
                if (args.length < 2 || !args[1].equalsIgnoreCase("confirm")) {
                    Util.msg(sender, "<yellow>This will demolish the casino around you. Type <white>/casino remove confirm</white> to proceed.");
                    return true;
                }
                Util.msg(sender, "<gold>Demolishing casino <white>" + r.id() + "<gold>...");
                BuildJob.demolish(plugin, r);
            }
            case "reload" -> {
                if (!sender.hasPermission("royalcasino.admin")) {
                    Util.msg(sender, "<red>You don't have permission.");
                    return true;
                }
                plugin.reloadAll();
                Util.msg(sender, "<green>Config reloaded.");
            }
            default -> {
                Util.msg(sender, "<gold>Casino commands:");
                Util.msg(sender, "<gray> /casino <white>- get the Casino Builder block");
                Util.msg(sender, "<gray> /casino give <player> <white>- give one to someone");
                Util.msg(sender, "<gray> /casino list <white>- list built casinos");
                Util.msg(sender, "<gray> /casino remove <white>- demolish the casino you're standing in");
                Util.msg(sender, "<gray> /casino reload <white>- reload config.yml");
                Util.msg(sender, "<gray> /chips ... <white>- chip balances (admins: add/remove/set/reset)");
            }
        }
        return true;
    }

    private void giveBuilder(CommandSender from, Player target) {
        ItemStack is = Items.builder(plugin);
        HashMap<Integer, ItemStack> left = target.getInventory().addItem(is);
        for (ItemStack rest : left.values()) target.getWorld().dropItemNaturally(target.getLocation(), rest);
        Util.sound(target, org.bukkit.Sound.ENTITY_ITEM_PICKUP, 1f, 1f);
        Util.msg(target, "<gold>You received the <yellow>Royal Casino Builder</yellow>. <gray>Place it on open ground, facing where the casino should go.");
        if (from != target) Util.msg(from, "<green>Gave the Casino Builder to " + target.getName() + ".");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("give", "list", "remove", "reload")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("remove")) {
            out.add("confirm");
        }
        return out;
    }
}

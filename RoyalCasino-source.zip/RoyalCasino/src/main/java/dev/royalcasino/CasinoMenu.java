package dev.royalcasino;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

/**
 * Base class for every casino GUI. The listener cancels all clicks; subclasses handle the ones they care about.
 * Rule for every game: chips are taken when a round starts and the result is decided immediately, so closing the
 * GUI mid-animation just settles the round at once (nobody can lose chips to a glitch or exploit a close).
 */
abstract class CasinoMenu implements InventoryHolder {
    protected final RoyalCasino plugin;
    protected final Player player;
    protected Inventory inv;
    protected int betIdx;
    protected BukkitTask task;
    private boolean closed;

    protected CasinoMenu(RoyalCasino plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        this.betIdx = plugin.betIndex(player.getUniqueId());
    }

    protected void create(int size, String title) {
        inv = Bukkit.createInventory(this, size, Util.raw(title));
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }

    Player player() {
        return player;
    }

    void open() {
        plugin.menus().add(this);
        player.openInventory(inv);
    }

    /** Called for clicks inside the top (casino) inventory only. */
    abstract void click(InventoryClickEvent e);

    /** Settle/refund anything pending. Called exactly once, when the GUI closes. */
    protected void onClose() {}

    /** Entry point used by the listener (and shutdown). Safe to call many times. */
    final void closed() {
        if (closed) return;
        closed = true;
        stopTask();
        try {
            onClose();
        } finally {
            plugin.menus().remove(this);
        }
    }

    void shutdown() {
        closed();
    }

    protected boolean isClosed() {
        return closed;
    }

    protected void stopTask() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    // ----- shared helpers -----

    protected long bet() {
        return plugin.betSteps()[betIdx];
    }

    /** Moves the bet size up (+1) or down (-1). Returns true if it changed. */
    protected boolean changeBet(int delta) {
        int n = Math.max(0, Math.min(plugin.betSteps().length - 1, betIdx + delta));
        if (n == betIdx) {
            Util.sound(player, Sound.BLOCK_NOTE_BLOCK_BASS, 0.6f, 0.8f);
            return false;
        }
        betIdx = n;
        plugin.setBetIndex(player.getUniqueId(), n);
        Util.sound(player, Sound.UI_BUTTON_CLICK, 0.6f, 1.0f + 0.05f * n);
        return true;
    }

    protected long balance() {
        return plugin.chips().get(player.getUniqueId());
    }

    protected boolean take(long amount) {
        return plugin.chips().take(player.getUniqueId(), amount);
    }

    protected void give(long amount) {
        if (amount > 0) plugin.chips().add(player.getUniqueId(), amount);
    }

    protected void noFunds() {
        Util.sound(player, Sound.ENTITY_VILLAGER_NO, 0.8f, 1f);
        Util.msg(player, "<red>Not enough chips. <gray>You have " + Util.chips(balance()) + "<gray>.");
    }

    protected void fill(Material m) {
        ItemStack p = Util.pane(m);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, p);
    }

    protected ItemStack betItem() {
        return Util.item(Material.GOLD_INGOT, "<yellow><bold>Bet: " + Util.n(bet()) + " chips",
                "<gray>Use <red>-</red> and <green>+</green> to change your bet.");
    }

    protected ItemStack balanceItem() {
        return Util.item(Material.GOLD_NUGGET, "<gold><bold>Your chips",
                "<yellow>" + Util.n(balance()) + " chips");
    }

    protected ItemStack minusItem() {
        return Util.item(Material.RED_CONCRETE, "<red><bold>- Lower bet");
    }

    protected ItemStack plusItem() {
        return Util.item(Material.LIME_CONCRETE, "<green><bold>+ Raise bet");
    }

    protected ItemStack closeItem() {
        return Util.item(Material.BARRIER, "<red>Close");
    }
}

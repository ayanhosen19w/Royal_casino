package dev.royalcasino;

enum GameType {
    SLOTS("slots", "Slot Machine"),
    ROULETTE("roulette", "Roulette"),
    BLACKJACK("blackjack", "Blackjack"),
    COINFLIP("coinflip", "Coin Flip"),
    DICE("dice", "Lucky Dice"),
    CASHIER("cashier", "Cashier");

    final String key;
    final String display;

    GameType(String key, String display) {
        this.key = key;
        this.display = display;
    }

    static GameType byKey(String key) {
        for (GameType t : values()) if (t.key.equalsIgnoreCase(key)) return t;
        return null;
    }
}

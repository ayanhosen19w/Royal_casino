package dev.royalcasino;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Blackjack vs the dealer. Infinite deck, dealer stands on 17, blackjack pays 3:2, double down on the first
 * two cards. (No split / insurance.) Closing the window mid-hand stands automatically and settles the hand.
 */
final class BlackjackMenu extends CasinoMenu {

    private enum Phase { BETTING, PLAYING, DEALER, DONE }

    private static final String[] RANKS = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
    private static final String[] SUITS = {"♠", "♥", "♦", "♣"};

    private Phase phase = Phase.BETTING;
    private final List<Integer> hand = new ArrayList<>();
    private final List<Integer> dealer = new ArrayList<>();
    private long wager;
    private boolean doubled;
    private boolean settled;
    private String status = "<gray>Place your bet and press <green>DEAL</green>.";

    BlackjackMenu(RoyalCasino plugin, Player player) {
        super(plugin, player);
        create(54, "<gradient:#ffd700:#ff9d00><bold>♠ Blackjack ♥</bold></gradient>");
        render();
    }

    // ---------- cards ----------

    private static int draw() {
        return ThreadLocalRandom.current().nextInt(52);
    }

    private static int rank(int card) {
        return card % 13;
    }

    private static int value(int card) {
        int r = rank(card);
        return r == 0 ? 11 : Math.min(10, r + 1);
    }

    /** Returns {total, isSoft}. */
    private static int[] total(List<Integer> cards) {
        int sum = 0, aces = 0;
        for (int c : cards) {
            sum += value(c);
            if (rank(c) == 0) aces++;
        }
        while (sum > 21 && aces > 0) {
            sum -= 10;
            aces--;
        }
        return new int[]{sum, aces > 0 ? 1 : 0};
    }

    private static boolean natural(List<Integer> cards) {
        return cards.size() == 2 && total(cards)[0] == 21;
    }

    private ItemStack cardItem(int card) {
        int suit = card / 13;
        String color = (suit == 1 || suit == 2) ? "<red>" : "<white>";
        return Util.item(Material.PAPER, 1, color + "<bold>" + SUITS[suit] + " " + RANKS[rank(card)], false,
                "<gray>Value: <yellow>" + (rank(card) == 0 ? "1 or 11" : String.valueOf(value(card))));
    }

    private ItemStack hidden() {
        return Util.item(Material.BOOK, "<gray><bold>Hidden card");
    }

    // ---------- rendering ----------

    private void render() {
        fill(Material.GREEN_STAINED_GLASS_PANE);
        for (int i = 0; i < 54; i++) {
            int row = i / 9, col = i % 9;
            if (row == 0 || col == 0 || col == 8) {
                inv.setItem(i, Util.pane((i % 2 == 0) ? Material.YELLOW_STAINED_GLASS_PANE : Material.ORANGE_STAINED_GLASS_PANE));
            }
        }
        boolean holeHidden = phase == Phase.PLAYING && !dealer.isEmpty();

        // dealer
        for (int i = 0; i < dealer.size() && i < 7; i++) {
            inv.setItem(10 + i, (i == 1 && holeHidden) ? hidden() : cardItem(dealer.get(i)));
        }
        String dLabel;
        if (dealer.isEmpty()) dLabel = "<gray>-";
        else if (holeHidden) dLabel = "<yellow>Showing " + value(dealer.get(0));
        else dLabel = "<yellow>" + total(dealer)[0] + (total(dealer)[0] > 21 ? " <red>BUST" : "");
        inv.setItem(4, Util.item(Material.PLAYER_HEAD, 1, "<white><bold>Dealer", false, dLabel));

        // player
        for (int i = 0; i < hand.size() && i < 7; i++) inv.setItem(28 + i, cardItem(hand.get(i)));
        String pLabel = hand.isEmpty() ? "<gray>-" : "<yellow>" + total(hand)[0]
                + (total(hand)[1] == 1 && total(hand)[0] < 21 ? " <gray>(soft)" : "")
                + (total(hand)[0] > 21 ? " <red>BUST" : "");
        inv.setItem(40, Util.item(Material.GOLD_INGOT, 1, "<white><bold>You", false, pLabel,
                phase == Phase.BETTING ? "<gray>Next bet: <yellow>" + Util.n(bet()) : "<gray>Wagered: <yellow>" + Util.n(wager)));

        inv.setItem(22, Util.item(Material.NAME_TAG, 1, status, false));

        inv.setItem(45, balanceItem());
        inv.setItem(53, closeItem());
        switch (phase) {
            case BETTING, DONE -> {
                inv.setItem(46, minusItem());
                inv.setItem(47, betItem());
                inv.setItem(48, plusItem());
                inv.setItem(49, Util.item(Material.LIME_CONCRETE, 1, phase == Phase.DONE ? "<green><bold>DEAL AGAIN" : "<green><bold>DEAL", true,
                        "<gray>Cost: <yellow>" + Util.n(bet()) + " chips"));
            }
            case PLAYING -> {
                inv.setItem(47, Util.item(Material.EMERALD_BLOCK, 1, "<green><bold>HIT", false, "<gray>Take another card"));
                inv.setItem(49, Util.item(Material.REDSTONE_BLOCK, 1, "<red><bold>STAND", false, "<gray>Keep your hand"));
                if (hand.size() == 2 && balance() >= wager) {
                    inv.setItem(51, Util.item(Material.GOLD_BLOCK, 1, "<gold><bold>DOUBLE DOWN", false,
                            "<gray>Double your bet, get exactly", "<gray>one more card, then stand.",
                            "<gray>Extra cost: <yellow>" + Util.n(wager)));
                }
            }
            case DEALER -> inv.setItem(49, Util.item(Material.GRAY_CONCRETE, "<gray><bold>Dealer plays..."));
        }
    }

    // ---------- clicks ----------

    @Override
    void click(InventoryClickEvent e) {
        int s = e.getRawSlot();
        if (s == 53) {
            player.closeInventory();
            return;
        }
        switch (phase) {
            case BETTING, DONE -> {
                switch (s) {
                    case 46 -> { if (changeBet(-1)) render(); }
                    case 48 -> { if (changeBet(1)) render(); }
                    case 49 -> deal();
                    default -> { }
                }
            }
            case PLAYING -> {
                switch (s) {
                    case 47 -> hit();
                    case 49 -> stand();
                    case 51 -> doubleDown();
                    default -> { }
                }
            }
            case DEALER -> { }
        }
    }

    // ---------- game flow ----------

    private void deal() {
        long b = bet();
        if (!take(b)) {
            noFunds();
            return;
        }
        wager = b;
        doubled = false;
        settled = false;
        hand.clear();
        dealer.clear();
        hand.add(draw());
        dealer.add(draw());
        hand.add(draw());
        dealer.add(draw());
        phase = Phase.PLAYING;
        status = "<yellow>Your move.";
        Util.sound(player, Sound.ITEM_BOOK_PAGE_TURN, 1f, 1f);
        if (natural(hand) || natural(dealer)) {
            resolve();
            return;
        }
        render();
    }

    private void hit() {
        hand.add(draw());
        Util.sound(player, Sound.ITEM_BOOK_PAGE_TURN, 1f, 1.2f);
        int t = total(hand)[0];
        if (t > 21) resolve();
        else if (t == 21) stand();
        else render();
    }

    private void doubleDown() {
        if (hand.size() != 2 || doubled) return;
        if (!take(wager)) {
            noFunds();
            return;
        }
        wager *= 2;
        doubled = true;
        hand.add(draw());
        Util.sound(player, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1f);
        if (total(hand)[0] > 21) resolve();
        else stand();
    }

    private void stand() {
        phase = Phase.DEALER;
        status = "<yellow>Dealer plays...";
        render();
        Util.sound(player, Sound.ITEM_BOOK_PAGE_TURN, 1f, 0.8f);
        task = Bukkit.getScheduler().runTaskLater(plugin, this::dealerStep, 12L);
    }

    private boolean dealerShouldHit() {
        int[] t = total(dealer);
        if (t[0] < 17) return true;
        return t[0] == 17 && t[1] == 1 && plugin.getConfig().getBoolean("games.blackjack.dealer-hits-soft-17", false);
    }

    private void dealerStep() {
        if (phase != Phase.DEALER) return;
        if (dealerShouldHit()) {
            dealer.add(draw());
            Util.sound(player, Sound.ITEM_BOOK_PAGE_TURN, 1f, 1.1f);
            render();
            task = Bukkit.getScheduler().runTaskLater(plugin, this::dealerStep, 14L);
        } else {
            resolve();
        }
    }

    private void resolve() {
        if (settled) return;
        settled = true;
        stopTask();
        phase = Phase.DONE;

        int pt = total(hand)[0], dt = total(dealer)[0];
        boolean pBJ = natural(hand), dBJ = natural(dealer);
        double bjPays = plugin.getConfig().getDouble("games.blackjack.blackjack-pays", 1.5);

        long payout;
        String outcome;
        if (pBJ && dBJ) {
            payout = wager;
            outcome = "<yellow>Push - both have blackjack.";
        } else if (pBJ) {
            payout = wager + (long) Math.floor(wager * bjPays);
            outcome = "<green><bold>BLACKJACK!";
        } else if (dBJ) {
            payout = 0;
            outcome = "<red>Dealer has blackjack.";
        } else if (pt > 21) {
            payout = 0;
            outcome = "<red>Bust! You went over 21.";
        } else if (dt > 21) {
            payout = wager * 2;
            outcome = "<green>Dealer busts - you win!";
        } else if (pt > dt) {
            payout = wager * 2;
            outcome = "<green>You win, " + pt + " beats " + dt + "!";
        } else if (pt == dt) {
            payout = wager;
            outcome = "<yellow>Push - " + pt + " each.";
        } else {
            payout = 0;
            outcome = "<red>Dealer wins, " + dt + " beats " + pt + ".";
        }

        give(payout);
        status = outcome;
        if (!isClosed()) render();

        if (payout > wager) {
            Util.msg(player, "<green>Blackjack: " + outcome + " <yellow>+" + Util.n(payout - wager) + " chips<gray>.");
            Fx.win(plugin, player, "Blackjack", wager, payout);
        } else if (payout == wager) {
            Util.msg(player, "<yellow>Blackjack: " + outcome + " <gray>Bet returned.");
            Util.sound(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1f);
        } else {
            Util.msg(player, "<red>Blackjack: " + outcome);
            Util.sound(player, Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.6f);
        }
    }

    @Override
    protected void onClose() {
        if (phase == Phase.PLAYING || phase == Phase.DEALER) {
            // Leaving mid-hand: stand and let the dealer finish instantly, then settle.
            while (dealerShouldHit()) dealer.add(draw());
            resolve();
        }
    }
}

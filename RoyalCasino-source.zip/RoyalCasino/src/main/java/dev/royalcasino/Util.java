package dev.royalcasino;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Small helpers: text, items, parsing. */
final class Util {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    static String prefix = "";

    private Util() {}

    /** MiniMessage text with italics turned off (for item names / lore). */
    static Component mm(String s) {
        return MM.deserialize("<!italic>" + s);
    }

    static Component raw(String s) {
        return MM.deserialize(s);
    }

    static void msg(CommandSender to, String s) {
        to.sendMessage(MM.deserialize(prefix + s));
    }

    static String n(long v) {
        return String.format(Locale.US, "%,d", v);
    }

    static String chips(long v) {
        return "<gold>" + n(v) + " chips</gold>";
    }

    static ItemStack item(Material m, String name, String... lore) {
        return item(m, 1, name, false, lore);
    }

    static ItemStack item(Material m, int amount, String name, boolean glow, String... lore) {
        ItemStack is = new ItemStack(m, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = is.getItemMeta();
        meta.displayName(mm(name));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(mm(s));
            meta.lore(l);
        }
        if (glow) meta.setEnchantmentGlintOverride(true);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        is.setItemMeta(meta);
        return is;
    }

    static ItemStack pane(Material m) {
        return item(m, " ");
    }

    /** First material name that exists on this server version (handles renames like CHAIN -> IRON_CHAIN). */
    static Material mat(String... names) {
        for (String n : names) {
            Material m = Material.matchMaterial(n);
            if (m != null) return m;
        }
        return Material.IRON_BARS;
    }

    /** Parses 1500, 1,500, 10k, 2.5m, 1b. Throws NumberFormatException on garbage. */
    static long parseAmount(String in) {
        String s = in.trim().toLowerCase(Locale.ROOT).replace(",", "").replace("_", "");
        double mult = 1;
        if (s.endsWith("k")) { mult = 1_000d; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("m")) { mult = 1_000_000d; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("b")) { mult = 1_000_000_000d; s = s.substring(0, s.length() - 1); }
        double v = Double.parseDouble(s) * mult;
        if (Double.isNaN(v) || Double.isInfinite(v) || v < 0 || v > ChipManager.MAX) throw new NumberFormatException();
        return Math.round(v);
    }

    static void sound(Player p, Sound s, float vol, float pitch) {
        p.playSound(p.getLocation(), s, vol, pitch);
    }
}

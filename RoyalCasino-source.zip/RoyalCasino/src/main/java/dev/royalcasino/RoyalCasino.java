package dev.royalcasino;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public final class RoyalCasino extends JavaPlugin {
    private ChipManager chips;
    private RegionManager regions;
    private final Set<CasinoMenu> menus = new LinkedHashSet<>();
    private final Set<BuildJob> jobs = new LinkedHashSet<>();
    private final Map<UUID, Integer> betIdx = new HashMap<>();
    private long[] betSteps = {10, 50, 100, 500, 1000};
    private NamespacedKey keyBuilder;
    private NamespacedKey keyGame;
    private NamespacedKey keyRegion;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        keyBuilder = new NamespacedKey(this, "builder");
        keyGame = new NamespacedKey(this, "casino_game");
        keyRegion = new NamespacedKey(this, "casino_region");
        loadSettings();

        chips = new ChipManager(this);
        chips.load();
        regions = new RegionManager(this);
        regions.load();

        getServer().getPluginManager().registerEvents(new CasinoListener(this), this);

        CasinoCommand casino = new CasinoCommand(this);
        getCommand("casino").setExecutor(casino);
        getCommand("casino").setTabCompleter(casino);
        ChipsCommand chipsCmd = new ChipsCommand(this);
        getCommand("chips").setExecutor(chipsCmd);
        getCommand("chips").setTabCompleter(chipsCmd);

        Bukkit.getScheduler().runTaskTimer(this, () -> chips.save(), 1200L, 1200L);
        Bukkit.getScheduler().runTaskTimer(this, this::actionBars, 40L, 40L);
        for (Player p : Bukkit.getOnlinePlayers()) chips.ensure(p.getUniqueId(), p.getName());

        getLogger().info("RoyalCasino enabled. Use /casino to get the Casino Builder block.");
    }

    @Override
    public void onDisable() {
        // Finish any casino that is still being built.
        for (BuildJob job : new ArrayList<>(jobs)) {
            try {
                job.finishNow();
            } catch (Exception e) {
                getLogger().warning("Could not finish a casino build: " + e.getMessage());
            }
        }
        // Settle every open game so nobody loses chips to a restart.
        for (CasinoMenu menu : new ArrayList<>(menus)) {
            try {
                menu.shutdown();
            } catch (Exception e) {
                getLogger().warning("Could not settle a game: " + e.getMessage());
            }
        }
        menus.clear();
        if (chips != null) chips.save();
        if (regions != null) regions.save();
    }

    void loadSettings() {
        Util.prefix = getConfig().getString("prefix", "<gold>Casino</gold> <dark_gray>»</dark_gray> ");
        List<Long> list = getConfig().getLongList("economy.bet-steps");
        list.removeIf(v -> v == null || v <= 0);
        if (list.isEmpty()) list = List.of(10L, 50L, 100L, 500L, 1000L);
        betSteps = list.stream().mapToLong(Long::longValue).toArray();
    }

    void reloadAll() {
        reloadConfig();
        loadSettings();
    }

    private void actionBars() {
        if (!getConfig().getBoolean("effects.actionbar-balance", true)) return;
        if (regions == null || regions.all().isEmpty()) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (regions.at(p.getLocation()) != null) {
                p.sendActionBar(Util.raw("<gold>◆ <yellow>" + Util.n(chips.get(p.getUniqueId())) + "</yellow> chips <gold>◆"));
            }
        }
    }

    /** Opens a game GUI for a player (checks the game is enabled and the player may play). */
    void openGame(Player p, GameType type) {
        if (p.getOpenInventory().getTopInventory().getHolder() instanceof CasinoMenu) return;   // already playing
        if (!p.hasPermission("royalcasino.play")) {
            Util.msg(p, "<red>You don't have permission to play.");
            return;
        }
        if (type != GameType.CASHIER && !getConfig().getBoolean("games." + type.key + ".enabled", true)) {
            Util.msg(p, "<red>" + type.display + " is closed right now.");
            return;
        }
        CasinoMenu menu = switch (type) {
            case SLOTS -> new SlotsMenu(this, p);
            case ROULETTE -> new RouletteMenu(this, p);
            case BLACKJACK -> new BlackjackMenu(this, p);
            case COINFLIP -> new CoinFlipMenu(this, p);
            case DICE -> new DiceMenu(this, p);
            case CASHIER -> new CashierMenu(this, p);
        };
        menu.open();
    }

    int betIndex(UUID id) {
        int def = getConfig().getInt("economy.default-bet-index", 3);
        int i = betIdx.getOrDefault(id, def);
        return Math.max(0, Math.min(betSteps.length - 1, i));
    }

    void setBetIndex(UUID id, int i) {
        betIdx.put(id, Math.max(0, Math.min(betSteps.length - 1, i)));
    }

    long[] betSteps() { return betSteps; }
    ChipManager chips() { return chips; }
    RegionManager regions() { return regions; }
    Set<CasinoMenu> menus() { return menus; }
    Set<BuildJob> jobs() { return jobs; }
    NamespacedKey keyBuilder() { return keyBuilder; }
    NamespacedKey keyGame() { return keyGame; }
    NamespacedKey keyRegion() { return keyRegion; }
}

package dev.royalcasino;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * /chips                       - your balance
 * /chips top                   - leaderboard
 * /chips pay <player> <amount> - send chips (if enabled in config)
 * Admins (royalcasino.admin):
 * /chips add|remove|set|reset <player> [amount]   /chips check <player>
 */
final class ChipsCommand implements CommandExecutor, TabCompleter {
    private final RoyalCasino plugin;

    ChipsCommand(RoyalCasino plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        ChipManager chips = plugin.chips();

        if (args.length == 0) {
            if (sender instanceof Player p) {
                Util.msg(p, "<gray>You have " + Util.chips(chips.get(p.getUniqueId())) + "<gray>.");
            } else {
                Util.msg(sender, "<gray>Usage: <white>/chips <add|remove|set|reset|check|top> ...");
            }
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "top", "leaderboard" -> {
                Util.msg(sender, "<gold><bold>Richest players");
                int rank = 1;
                for (Map.Entry<UUID, Long> e : chips.top(10)) {
                    Util.msg(sender, "<gray>" + rank++ + ". <white>" + chips.name(e.getKey()) + " <dark_gray>- " + Util.chips(e.getValue()));
                }
            }
            case "pay" -> pay(sender, args);
            case "add", "give", "remove", "take", "set", "reset", "check", "balance", "bal" -> admin(sender, sub, args);
            default -> Util.msg(sender, "<gray>Usage: <white>/chips [top | pay <player> <amount>]"
                    + (sender.hasPermission("royalcasino.admin") ? " <gray>| admin: <white>add/remove/set/reset/check <player> [amount]" : ""));
        }
        return true;
    }

    private void pay(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            Util.msg(sender, "<red>Only players can pay chips.");
            return;
        }
        if (!plugin.getConfig().getBoolean("economy.allow-player-pay", false) && !p.hasPermission("royalcasino.admin")) {
            Util.msg(p, "<red>Paying other players is disabled.");
            return;
        }
        if (args.length < 3) {
            Util.msg(p, "<gray>Usage: <white>/chips pay <player> <amount>");
            return;
        }
        UUID target = resolve(args[1]);
        if (target == null) {
            Util.msg(p, "<red>Unknown player. They must have joined the server once.");
            return;
        }
        if (target.equals(p.getUniqueId())) {
            Util.msg(p, "<red>You can't pay yourself.");
            return;
        }
        long amount;
        try {
            amount = Util.parseAmount(args[2]);
        } catch (NumberFormatException ex) {
            Util.msg(p, "<red>That's not a valid amount.");
            return;
        }
        if (amount <= 0) {
            Util.msg(p, "<red>Amount must be above zero.");
            return;
        }
        if (!plugin.chips().take(p.getUniqueId(), amount)) {
            Util.msg(p, "<red>You don't have that many chips.");
            return;
        }
        plugin.chips().add(target, amount);
        Util.msg(p, "<green>Sent " + Util.chips(amount) + "<green> to " + plugin.chips().name(target) + ".");
        Player tp = Bukkit.getPlayer(target);
        if (tp != null) {
            Util.msg(tp, "<green>" + p.getName() + " sent you " + Util.chips(amount) + "<green>.");
            tp.playSound(tp.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
        }
    }

    private void admin(CommandSender sender, String sub, String[] args) {
        if (!sender.hasPermission("royalcasino.admin")) {
            Util.msg(sender, "<red>You don't have permission.");
            return;
        }
        if (args.length < 2) {
            Util.msg(sender, "<gray>Usage: <white>/chips " + sub + " <player>" + (sub.equals("check") || sub.equals("reset") ? "" : " <amount>"));
            return;
        }
        UUID target = resolve(args[1]);
        if (target == null) {
            Util.msg(sender, "<red>Unknown player <white>" + args[1] + "<red>. They must have joined the server once.");
            return;
        }
        ChipManager chips = plugin.chips();
        String name = chips.name(target);
        Player online = Bukkit.getPlayer(target);

        if (sub.equals("check") || sub.equals("balance") || sub.equals("bal")) {
            Util.msg(sender, "<white>" + name + " <gray>has " + Util.chips(chips.get(target)) + "<gray>.");
            return;
        }
        if (sub.equals("reset")) {
            chips.set(target, 0);
            Util.msg(sender, "<green>Reset " + name + "'s chips to 0.");
            if (online != null) Util.msg(online, "<yellow>Your chips were reset by an admin.");
            return;
        }

        if (args.length < 3) {
            Util.msg(sender, "<gray>Usage: <white>/chips " + sub + " <player> <amount>  <gray>(10k, 2.5m and 1b also work)");
            return;
        }
        long amount;
        try {
            amount = Util.parseAmount(args[2]);
        } catch (NumberFormatException ex) {
            Util.msg(sender, "<red>That's not a valid amount.");
            return;
        }

        switch (sub) {
            case "add", "give" -> {
                long now = chips.add(target, amount);
                Util.msg(sender, "<green>Added " + Util.chips(amount) + "<green> to " + name + ". <gray>Balance: " + Util.chips(now));
                if (online != null) {
                    Util.msg(online, "<green>You received " + Util.chips(amount) + "<green> from the casino staff! <gray>Balance: " + Util.chips(now));
                    online.playSound(online.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
                }
            }
            case "remove", "take" -> {
                long have = chips.get(target);
                long taken = Math.min(have, amount);
                chips.take(target, taken);
                Util.msg(sender, "<green>Removed " + Util.chips(taken) + "<green> from " + name + ". <gray>Balance: " + Util.chips(chips.get(target)));
                if (online != null) Util.msg(online, "<yellow>An admin removed " + Util.chips(taken) + "<yellow> from your balance.");
            }
            case "set" -> {
                chips.set(target, amount);
                Util.msg(sender, "<green>Set " + name + "'s chips to " + Util.chips(amount) + "<green>.");
                if (online != null) Util.msg(online, "<yellow>An admin set your chips to " + Util.chips(amount) + "<yellow>.");
            }
            default -> { }
        }
    }

    private UUID resolve(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            plugin.chips().ensure(online.getUniqueId(), online.getName());
            return online.getUniqueId();
        }
        return plugin.chips().find(name);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = sender.hasPermission("royalcasino.admin");
        if (args.length == 1) {
            List<String> subs = new ArrayList<>(List.of("top", "pay"));
            if (admin) subs.addAll(List.of("add", "remove", "set", "reset", "check"));
            for (String s : subs) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            boolean needsPlayer = sub.equals("pay") || (admin && List.of("add", "give", "remove", "take", "set", "reset", "check").contains(sub));
            if (needsPlayer) {
                Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
                for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
                if (admin) names.addAll(plugin.chips().knownNames());
                for (String n : names) if (n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(n);
            }
        } else if (args.length == 3) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (List.of("add", "give", "remove", "take", "set", "pay").contains(sub)) out.addAll(List.of("100", "1000", "10k", "100k", "1m"));
        }
        return out;
    }
}

package dev.royalcasino;

import org.bukkit.Material;
import org.bukkit.block.BlockFace;

import java.util.ArrayList;
import java.util.List;

/**
 * The casino blueprint in LOCAL coordinates (x = 0..W-1 left-right, y = 0..H-1 up, z = 0..D-1 front-to-back).
 * z = 0 is the front edge of the entrance plaza (where the builder block was placed, at x = CX).
 * Every cell that is null becomes air. Rotation into the world is done by {@link Frame}.
 */
final class CasinoPlan {
    static final int W = 33, D = 34, H = 11, CX = 16;
    static final int FRONT = 3;      // z of the front wall (0..2 is the entrance plaza)

    record Cell(Material m, BlockFace face, boolean top) {}

    /** An invisible click target that opens a game. x/y/z are continuous local coordinates (floor of the box). */
    record Station(GameType type, double x, double y, double z, float w, float h) {}

    /** A floating text label. */
    record Label(String text, double x, double y, double z, boolean marquee) {}

    private final Cell[][][] g = new Cell[H][D][W];   // [y][z][x]
    final List<Station> stations = new ArrayList<>();
    final List<Label> labels = new ArrayList<>();
    private final String casinoName;

    // palette
    private static final Material WALL = Material.POLISHED_BLACKSTONE_BRICKS;
    private static final Material PILLAR = Material.GILDED_BLACKSTONE;
    private static final Material GOLD = Material.GOLD_BLOCK;
    private static final Material GLASS = Material.PURPLE_STAINED_GLASS;
    private static final Material LAMP = Material.SHROOMLIGHT;

    CasinoPlan(String casinoName) {
        this.casinoName = casinoName;
        build();
    }

    Cell at(int y, int z, int x) {
        return g[y][z][x];
    }

    // ---------- tiny drawing API ----------

    private boolean in(int x, int y, int z) {
        return x >= 0 && x < W && y >= 0 && y < H && z >= 0 && z < D;
    }

    private void set(int x, int y, int z, Material m) {
        if (in(x, y, z)) g[y][z][x] = new Cell(m, null, false);
    }

    private void set(int x, int y, int z, Material m, BlockFace face, boolean top) {
        if (in(x, y, z)) g[y][z][x] = new Cell(m, face, top);
    }

    private void clear(int x, int y, int z) {
        if (in(x, y, z)) g[y][z][x] = null;
    }

    private void fill(int x1, int y1, int z1, int x2, int y2, int z2, Material m) {
        for (int y = y1; y <= y2; y++)
            for (int z = z1; z <= z2; z++)
                for (int x = x1; x <= x2; x++) set(x, y, z, m);
    }

    private void table(int x1, int z1, int x2, int z2, Material body, Material felt) {
        fill(x1, 1, z1, x2, 1, z2, body);
        fill(x1 + 1, 2, z1 + 1, x2 - 1, 2, z2 - 1, felt);
    }

    private void stool(int x, int z, BlockFace face) {
        set(x, 1, z, Material.DARK_OAK_STAIRS, face, false);
    }

    private void station(GameType t, int x1, int z1, int x2, int z2, float w) {
        stations.add(new Station(t, (x1 + x2 + 1) / 2.0, 1.0, (z1 + z2 + 1) / 2.0, w, 2.5f));
    }

    private void label(String text, double x, double y, double z) {
        labels.add(new Label(text, x, y, z, false));
    }

    // ---------- the build ----------

    private void build() {
        final int FZ = FRONT;
        final int BZ = D - 1;
        final int RX = W - 1;

        // ===== floor =====
        for (int z = 0; z <= BZ; z++) {
            for (int x = 0; x <= RX; x++) {
                boolean even = ((x + z) & 1) == 0;
                if (z < FZ) set(x, 0, z, even ? Material.SMOOTH_QUARTZ : Material.POLISHED_ANDESITE);
                else set(x, 0, z, even ? Material.POLISHED_BLACKSTONE : Material.POLISHED_DEEPSLATE);
            }
        }
        // golden ring inside the hall
        for (int x = 2; x <= 30; x++) {
            set(x, 0, 5, GOLD);
            set(x, 0, 31, GOLD);
        }
        for (int z = 5; z <= 31; z++) {
            set(2, 0, z, GOLD);
            set(30, 0, z, GOLD);
        }
        // rugs
        fill(2, 0, 30, 30, 0, 32, Material.PURPLE_CONCRETE);     // in front of the slot machines
        fill(3, 0, 12, 9, 0, 19, Material.PURPLE_CONCRETE);      // blackjack
        fill(3, 0, 20, 9, 0, 26, Material.PURPLE_CONCRETE);      // bar
        fill(23, 0, 12, 29, 0, 19, Material.PURPLE_CONCRETE);    // dice
        fill(23, 0, 20, 29, 0, 27, Material.PURPLE_CONCRETE);    // coin flip
        fill(11, 0, 14, 21, 0, 20, Material.RED_CONCRETE);       // roulette
        // red carpet runway from the street to the roulette table
        fill(14, 0, 0, 18, 0, 13, Material.RED_CONCRETE);
        fill(13, 0, 0, 13, 0, 13, GOLD);
        fill(19, 0, 0, 19, 0, 13, GOLD);

        // ===== walls =====
        for (int y = 1; y <= 8; y++) {
            for (int z = FZ; z <= BZ; z++) {
                for (int x = 0; x <= RX; x++) {
                    boolean edge = x == 0 || x == RX || z == FZ || z == BZ;
                    if (!edge) continue;
                    boolean pillar;
                    if (z == FZ || z == BZ) pillar = (x == 0 || x == RX || x % 6 == 0);
                    else pillar = ((z - FZ) % 6 == 0);
                    Material m = WALL;
                    if (pillar) m = PILLAR;
                    else if (y == 8) m = GOLD;
                    else if (y >= 3 && y <= 6 && !(z == FZ && Math.abs(x - CX) < 7)) m = GLASS;
                    set(x, y, z, m);
                }
            }
        }
        // ceiling / roof
        fill(0, 9, FZ, RX, 9, BZ, Material.POLISHED_BLACKSTONE);
        for (int x = 2; x <= 30; x += 4) for (int z = 6; z <= 30; z += 4) set(x, 9, z, LAMP);
        // golden frame + glass skylight over the roulette table
        for (int x = 12; x <= 20; x++) {
            set(x, 9, 14, GOLD);
            set(x, 9, 22, GOLD);
        }
        for (int z = 14; z <= 22; z++) {
            set(12, 9, z, GOLD);
            set(20, 9, z, GOLD);
        }
        fill(13, 9, 15, 19, 9, 21, GLASS);
        // crenellated parapet
        for (int z = FZ; z <= BZ; z++) {
            for (int x = 0; x <= RX; x++) {
                boolean edge = x == 0 || x == RX || z == FZ || z == BZ;
                if (!edge) continue;
                boolean corner = (x == 0 || x == RX) && (z == FZ || z == BZ);
                if (corner) set(x, 10, z, GOLD);
                else if (((x + z) & 1) == 0) set(x, 10, z, WALL);
            }
        }

        // ===== entrance =====
        for (int y = 1; y <= 4; y++) for (int x = 14; x <= 18; x++) clear(x, y, FZ);
        for (int y = 1; y <= 4; y++) {
            set(13, y, FZ, Material.QUARTZ_PILLAR);
            set(19, y, FZ, Material.QUARTZ_PILLAR);
        }
        fill(9, 5, FZ, 23, 5, FZ, GOLD);                        // lintel
        fill(9, 6, FZ, 23, 7, FZ, Material.BLACK_CONCRETE);     // marquee board
        fill(9, 8, FZ, 23, 8, FZ, GOLD);
        fill(8, 5, FZ, 8, 8, FZ, GOLD);
        fill(24, 5, FZ, 24, 8, FZ, GOLD);
        labels.add(new Label(casinoName, CX + 0.5, 7.0, FZ - 0.08, true));

        // lamp posts on the plaza
        for (int px : new int[]{3, 11, 21, 29}) {
            fill(px, 1, 1, px, 2, 1, Material.POLISHED_BLACKSTONE_BRICK_WALL);
            set(px, 3, 1, Material.LANTERN);
        }

        // ===== interior pillars =====
        for (int[] p : new int[][]{{10, 10}, {22, 10}, {10, 26}, {22, 26}}) {
            set(p[0], 1, p[1], GOLD);
            fill(p[0], 2, p[1], p[0], 7, p[1], Material.QUARTZ_PILLAR);
            set(p[0], 8, p[1], GOLD);
        }

        // ===== chandeliers =====
        Material chain = Util.mat("CHAIN", "IRON_CHAIN", "IRON_BARS");
        for (int[] c : new int[][]{{11, 12}, {21, 12}, {11, 21}, {21, 21}}) {
            set(c[0], 8, c[1], chain);
            set(c[0], 7, c[1], chain);
            set(c[0], 6, c[1], Material.LANTERN, null, true);
            set(c[0] + 1, 6, c[1], Material.LANTERN, null, true);
            set(c[0] - 1, 6, c[1], Material.LANTERN, null, true);
            set(c[0], 6, c[1] + 1, Material.LANTERN, null, true);
            set(c[0], 6, c[1] - 1, Material.LANTERN, null, true);
        }

        // ===== fountain (x3..7, z6..10) =====
        for (int x = 3; x <= 7; x++) {
            for (int z = 6; z <= 10; z++) {
                boolean rim = x == 3 || x == 7 || z == 6 || z == 10;
                set(x, 1, z, rim ? Material.QUARTZ_BLOCK : Material.WATER);
            }
        }
        set(5, 1, 8, Material.QUARTZ_PILLAR);
        set(5, 2, 8, Material.QUARTZ_PILLAR);
        set(5, 3, 8, Material.SEA_LANTERN);

        // ===== cashier (x25..29, z7) =====
        fill(25, 1, 7, 29, 1, 7, Material.QUARTZ_BLOCK);
        for (int x = 25; x <= 29; x++) set(x, 2, 7, Material.QUARTZ_SLAB, null, false);
        set(26, 1, 5, Material.EMERALD_BLOCK);
        set(27, 1, 5, GOLD);
        set(28, 1, 5, Material.DIAMOND_BLOCK);
        set(27, 2, 5, LAMP);
        station(GameType.CASHIER, 25, 7, 29, 7, 5.4f);
        label("<gold><bold>♛ CASHIER ♛</bold>\n<gray>Check your chips", 27.5, 3.3, 7.5);

        // ===== blackjack (x3..9, z13..17) =====
        table(3, 13, 9, 17, Material.DARK_OAK_PLANKS, Material.GREEN_CARPET);
        set(5, 2, 15, Material.LIGHT_WEIGHTED_PRESSURE_PLATE);
        set(7, 2, 15, Material.HEAVY_WEIGHTED_PRESSURE_PLATE);
        for (int x : new int[]{4, 6, 8}) stool(x, 19, BlockFace.NORTH);
        station(GameType.BLACKJACK, 3, 13, 9, 17, 7.4f);
        label("<white><bold>♠ BLACKJACK ♥</bold>\n<gray>Right-click to play", 6.5, 3.5, 15.5);

        // ===== dice (x23..29, z13..17) =====
        table(23, 13, 29, 17, Material.RED_NETHER_BRICKS, Material.RED_CARPET);
        set(25, 2, 15, Material.BONE_BLOCK);
        set(27, 2, 15, Material.BONE_BLOCK);
        for (int x : new int[]{24, 26, 28}) stool(x, 19, BlockFace.NORTH);
        station(GameType.DICE, 23, 13, 29, 17, 7.4f);
        label("<aqua><bold>⚄ LUCKY DICE ⚄</bold>\n<gray>Right-click to play", 26.5, 3.5, 15.5);

        // ===== coin flip (x23..29, z21..25) =====
        table(23, 21, 29, 25, Material.DARK_OAK_PLANKS, Material.YELLOW_CARPET);
        set(26, 2, 23, GOLD);
        set(26, 3, 23, Material.LIGHT_WEIGHTED_PRESSURE_PLATE);
        for (int x : new int[]{24, 26, 28}) stool(x, 27, BlockFace.NORTH);
        station(GameType.COINFLIP, 23, 21, 29, 25, 7.4f);
        label("<gold><bold>◎ COIN FLIP ◎</bold>\n<gray>Right-click to play", 26.5, 4.2, 23.5);

        // ===== roulette (x12..20, z15..19) =====
        table(12, 15, 20, 19, Material.DARK_OAK_PLANKS, Material.GREEN_CARPET);
        for (int x = 15; x <= 17; x++)
            for (int z = 16; z <= 18; z++)
                set(x, 2, z, ((x + z) & 1) == 0 ? Material.RED_CONCRETE : Material.BLACK_CONCRETE);
        set(16, 2, 17, GOLD);
        set(16, 3, 17, Material.LANTERN);
        station(GameType.ROULETTE, 12, 15, 20, 19, 9.4f);
        label("<red><bold>◉ ROULETTE ◉</bold>\n<gray>Right-click to play", 16.5, 4.8, 17.5);

        // ===== lounge bar (x3..9, z21..25) - decoration =====
        fill(3, 1, 23, 9, 1, 23, Material.DARK_OAK_PLANKS);
        set(4, 2, 23, Material.LANTERN);
        set(8, 2, 23, Material.LANTERN);
        fill(3, 1, 25, 9, 3, 25, Material.BOOKSHELF);
        for (int x : new int[]{4, 6, 8}) stool(x, 21, BlockFace.SOUTH);
        label("<yellow>Lounge Bar", 6.5, 4.2, 23.5);

        // ===== slot machines on the back wall =====
        for (int cx : new int[]{4, 10, 16, 22, 28}) {
            for (int dx = -1; dx <= 1; dx++) {
                set(cx + dx, 1, 32, Material.BLACK_CONCRETE);
                set(cx + dx, 3, 32, Material.SEA_LANTERN);
                set(cx + dx, 4, 32, dx == 0 ? LAMP : GOLD);
            }
            set(cx - 1, 2, 32, Material.RED_CONCRETE);
            set(cx, 2, 32, GOLD);
            set(cx + 1, 2, 32, Material.DIAMOND_BLOCK);
            stations.add(new Station(GameType.SLOTS, cx + 0.5, 1.0, 32.5, 3.0f, 3.2f));
            label("<gold><bold>★ SLOTS ★</bold>\n<gray>Right-click to play", cx + 0.5, 5.6, 31.5);
        }
        label("<light_purple><bold>★ PROGRESSIVE JACKPOT ★</bold>\n<gray>Match 3 <light_purple>Lucky Stars", 16.5, 7.0, 31.5);

        // ===== welcome sign inside the door =====
        label("<gradient:#ffd700:#ff9d00><bold>Welcome!</bold></gradient>\n<gray>Right-click any table or machine\n<gray>Chips come from the staff", 16.5, 3.6, 8.5);
    }
}

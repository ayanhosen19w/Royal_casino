package dev.royalcasino;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Two dice. Bet Under 7 (15/36), Exactly 7 (6/36) or Over 7 (15/36).
 * Default payouts 2.3x / 5.7x / 2.3x give about 4-5% house edge.
 */
final class DiceMenu extends CasinoMenu {
    private static final int UNDER = 0, SEVEN = 1, OVER = 2;

    private int pick = UNDER;
    private boolean busy;
    private int d1 = 1, d2 = 1;
    private int fin1, fin2;
    private int frame;
    private long pendingWager;
    private long pendingPayout;

    DiceMenu(RoyalCasino plugin, Player player) {
        super(plugin, player);
        create(27, "<gradient:#ffd700:#ff9d00><bold>⚄ Lucky Dice ⚄</bold></gradient>");
        fill(Material.BLACK_STAINED_GLASS_PANE);
        for (int i = 0; i < 27; i++) {
            if (i < 9 || i >= 18) inv.setItem(i, Util.pane((i % 2 == 0) ? Material.YELLOW_STAINED_GLASS_PANE : Material.ORANGE_STAINED_GLASS_PANE));
        }
        render();
    }

    private double mult(int type) {
        return type == SEVEN
                ? plugin.getConfig().getDouble("games.dice.seven-payout", 5.7)
                : plugin.getConfig().getDouble("games.dice.under-over-payout", 2.3);
    }

    private ItemStack die(int v) {
        return Util.item(Material.WHITE_CONCRETE, v, "<white><bold>Die: " + v, false);
    }

    private void render() {
        inv.setItem(3, die(d1));
        inv.setItem(5, die(d2));
        inv.setItem(4, Util.item(Material.PAPER, 1, "<yellow><bold>Total: " + (d1 + d2), false));
        inv.setItem(11, Util.item(Material.LIGHT_BLUE_CONCRETE, 1, "<aqua><bold>UNDER 7", pick == UNDER,
                "<gray>Total 2-6", "<gray>Pays <yellow>" + mult(UNDER) + "x", pick == UNDER ? "<green>● Selected" : "<dark_gray>Click to select"));
        inv.setItem(13, Util.item(Material.GOLD_BLOCK, 1, "<gold><bold>EXACTLY 7", pick == SEVEN,
                "<gray>Total 7", "<gray>Pays <yellow>" + mult(SEVEN) + "x", pick == SEVEN ? "<green>● Selected" : "<dark_gray>Click to select"));
        inv.setItem(15, Util.item(Material.RED_CONCRETE, 1, "<red><bold>OVER 7", pick == OVER,
                "<gray>Total 8-12", "<gray>Pays <yellow>" + mult(OVER) + "x", pick == OVER ? "<green>● Selected" : "<dark_gray>Click to select"));
        inv.setItem(18, balanceItem());
        inv.setItem(19, minusItem());
        inv.setItem(20, betItem());
        inv.setItem(21, plusItem());
        inv.setItem(23, busy
                ? Util.item(Material.GRAY_CONCRETE, "<gray><bold>Rolling...")
                : Util.item(Material.LIME_CONCRETE, 1, "<green><bold>ROLL", true, "<gray>Cost: <yellow>" + Util.n(bet()) + " chips"));
        inv.setItem(26, closeItem());
    }

    @Override
    void click(InventoryClickEvent e) {
        int s = e.getRawSlot();
        if (s == 26) {
            player.closeInventory();
            return;
        }
        if (busy) return;
        switch (s) {
            case 11 -> select(UNDER);
            case 13 -> select(SEVEN);
            case 15 -> select(OVER);
            case 19 -> { if (changeBet(-1)) render(); }
            case 21 -> { if (changeBet(1)) render(); }
            case 23 -> roll();
            default -> { }
        }
    }

    private void select(int t) {
        pick = t;
        Util.sound(player, Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
        render();
    }

    private void roll() {
        long b = bet();
        if (!take(b)) {
            noFunds();
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        fin1 = r.nextInt(1, 7);
        fin2 = r.nextInt(1, 7);
        int sum = fin1 + fin2;
        boolean win = (pick == UNDER && sum < 7) || (pick == SEVEN && sum == 7) || (pick == OVER && sum > 7);
        pendingWager = b;
        pendingPayout = win ? (long) Math.floor(b * mult(pick)) : 0L;

        busy = true;
        frame = 0;
        render();
        Util.sound(player, Sound.BLOCK_WOOD_HIT, 0.8f, 1.4f);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 2L);
    }

    private void tick() {
        frame++;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        d1 = r.nextInt(1, 7);
        d2 = r.nextInt(1, 7);
        inv.setItem(3, die(d1));
        inv.setItem(5, die(d2));
        inv.setItem(4, Util.item(Material.PAPER, 1, "<yellow><bold>Total: ?", false));
        Util.sound(player, Sound.BLOCK_WOOD_STEP, 0.6f, 1.0f + 0.05f * frame);
        if (frame >= 12) finish();
    }

    private void finish() {
        if (!busy) return;
        busy = false;
        stopTask();
        d1 = fin1;
        d2 = fin2;
        give(pendingPayout);
        if (!isClosed()) render();

        String rolled = "<white>" + d1 + " + " + d2 + " = <yellow>" + (d1 + d2);
        if (pendingPayout > pendingWager) {
            Util.msg(player, "<green>Dice: " + rolled + "<green>! <yellow>+" + Util.n(pendingPayout - pendingWager) + " chips<gray>.");
            Fx.win(plugin, player, "Lucky Dice", pendingWager, pendingPayout);
        } else {
            Util.msg(player, "<red>Dice: " + rolled + "<red>. <gray>No win.");
            Util.sound(player, Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.6f);
        }
    }

    @Override
    protected void onClose() {
        if (busy) finish();
    }
}

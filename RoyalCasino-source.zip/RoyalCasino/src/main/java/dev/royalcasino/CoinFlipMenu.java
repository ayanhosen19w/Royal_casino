package dev.royalcasino;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.concurrent.ThreadLocalRandom;

/** Heads or tails. 50/50, pays 1.95x by default (2.5% house edge). */
final class CoinFlipMenu extends CasinoMenu {
    private int pick;            // 0 = heads, 1 = tails
    private boolean busy;
    private int shown;           // side currently displayed
    private int result;
    private int flipsLeft;
    private int flipNo;
    private long pendingWager;
    private long pendingPayout;

    CoinFlipMenu(RoyalCasino plugin, Player player) {
        super(plugin, player);
        create(27, "<gradient:#ffd700:#ff9d00><bold>◎ Coin Flip ◎</bold></gradient>");
        fill(Material.BLACK_STAINED_GLASS_PANE);
        for (int i = 0; i < 27; i++) {
            if (i < 9 || i >= 18) inv.setItem(i, Util.pane((i % 2 == 0) ? Material.YELLOW_STAINED_GLASS_PANE : Material.ORANGE_STAINED_GLASS_PANE));
        }
        render();
    }

    private ItemStack coin(int side) {
        return side == 0
                ? Util.item(Material.GOLD_INGOT, 1, "<gold><bold>HEADS", false)
                : Util.item(Material.IRON_INGOT, 1, "<white><bold>TAILS", false);
    }

    private double payout() {
        return plugin.getConfig().getDouble("games.coinflip.payout", 1.95);
    }

    private void render() {
        double pay = payout();
        inv.setItem(11, Util.item(Material.GOLD_BLOCK, 1, "<gold><bold>HEADS", pick == 0,
                "<gray>Pays <yellow>" + pay + "x", pick == 0 ? "<green>● Selected" : "<dark_gray>Click to select"));
        inv.setItem(15, Util.item(Material.IRON_BLOCK, 1, "<white><bold>TAILS", pick == 1,
                "<gray>Pays <yellow>" + pay + "x", pick == 1 ? "<green>● Selected" : "<dark_gray>Click to select"));
        inv.setItem(13, coin(shown));
        inv.setItem(18, balanceItem());
        inv.setItem(19, minusItem());
        inv.setItem(20, betItem());
        inv.setItem(21, plusItem());
        inv.setItem(23, busy
                ? Util.item(Material.GRAY_CONCRETE, "<gray><bold>Flipping...")
                : Util.item(Material.LIME_CONCRETE, 1, "<green><bold>FLIP", true, "<gray>Cost: <yellow>" + Util.n(bet()) + " chips"));
        inv.setItem(26, closeItem());
    }

    @Override
    void click(InventoryClickEvent e) {
        int s = e.getRawSlot();
        if (s == 26) {
            player.closeInventory();
            return;
        }
        if (busy) return;
        switch (s) {
            case 11 -> { pick = 0; Util.sound(player, Sound.UI_BUTTON_CLICK, 0.6f, 1.2f); render(); }
            case 15 -> { pick = 1; Util.sound(player, Sound.UI_BUTTON_CLICK, 0.6f, 1.2f); render(); }
            case 19 -> { if (changeBet(-1)) render(); }
            case 21 -> { if (changeBet(1)) render(); }
            case 23 -> flip();
            default -> { }
        }
    }

    private void flip() {
        long b = bet();
        if (!take(b)) {
            noFunds();
            return;
        }
        result = ThreadLocalRandom.current().nextBoolean() ? 0 : 1;
        pendingWager = b;
        pendingPayout = (result == pick) ? (long) Math.floor(b * payout()) : 0L;

        // Make the animation end exactly on the result.
        flipsLeft = (Math.floorMod(result - shown, 2) == 0) ? 14 : 15;
        flipNo = 0;
        busy = true;
        render();
        Util.sound(player, Sound.ITEM_TRIDENT_THROW, 0.7f, 1.6f);
        schedule();
    }

    private void schedule() {
        int delay = 1 + flipNo / 4;
        task = Bukkit.getScheduler().runTaskLater(plugin, this::step, delay);
    }

    private void step() {
        shown = 1 - shown;
        flipNo++;
        flipsLeft--;
        inv.setItem(13, coin(shown));
        Util.sound(player, Sound.BLOCK_NOTE_BLOCK_CHIME, 0.5f, 0.8f + 0.04f * flipNo);
        if (flipsLeft <= 0) finish();
        else schedule();
    }

    private void finish() {
        if (!busy) return;
        busy = false;
        stopTask();
        shown = result;
        give(pendingPayout);
        if (!isClosed()) render();

        String side = result == 0 ? "<gold>HEADS" : "<white>TAILS";
        if (pendingPayout > pendingWager) {
            Util.msg(player, "<green>Coin Flip: it landed " + side + "<green>! <yellow>+" + Util.n(pendingPayout - pendingWager) + " chips<gray>.");
            Fx.win(plugin, player, "Coin Flip", pendingWager, pendingPayout);
        } else {
            Util.msg(player, "<red>Coin Flip: it landed " + side + "<red>. <gray>Better luck next time.");
            Util.sound(player, Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.6f);
        }
    }

    @Override
    protected void onClose() {
        if (busy) finish();
    }
}

package dev.royalcasino;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;

import java.time.Duration;

/** Win effects: sounds, particles, fireworks, titles, server broadcasts. */
final class Fx {
    private Fx() {}

    static void firework(Location loc, Color... colors) {
        if (loc.getWorld() == null) return;
        Firework fw = loc.getWorld().spawn(loc, Firework.class, f -> {
            FireworkMeta meta = f.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder()
                    .with(FireworkEffect.Type.BALL_LARGE)
                    .withColor(colors.length == 0 ? new Color[]{Color.YELLOW, Color.ORANGE} : colors)
                    .withFade(Color.WHITE)
                    .flicker(true)
                    .trail(true)
                    .build());
            meta.setPower(0);
            f.setFireworkMeta(meta);
        });
        fw.detonate();
    }

    /** Celebrate a round where the player got back more than they wagered. */
    static void win(RoyalCasino plugin, Player p, String game, long wager, long payout) {
        if (payout <= wager) return;
        long profit = payout - wager;
        double mult = wager <= 0 ? 0 : (double) payout / wager;
        Location l = p.getLocation().add(0, 1, 0);

        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
        p.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, l, 25, 0.6, 0.6, 0.6, 0);
        if (mult >= 5) {
            p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, l, 60, 0.5, 0.8, 0.5, 0.3);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            firework(l);
        }
        if (mult >= 25) {
            p.getWorld().strikeLightningEffect(p.getLocation());
            firework(l.clone().add(2, 0, 0), Color.AQUA, Color.WHITE);
            firework(l.clone().add(-2, 0, 0), Color.FUCHSIA, Color.YELLOW);
        }

        p.showTitle(Title.title(
                Util.raw("<gradient:#ffd700:#ffae00><bold>YOU WIN!</bold></gradient>"),
                Util.raw("<yellow>+" + Util.n(profit) + " chips</yellow>"),
                Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(1500), Duration.ofMillis(400))));

        long threshold = plugin.getConfig().getLong("effects.big-win-broadcast", 10000L);
        if (threshold > 0 && profit >= threshold) {
            Bukkit.broadcast(Util.raw(Util.prefix + "<gold>★ <yellow>" + p.getName() + "</yellow> just won <yellow>"
                    + Util.n(profit) + " chips</yellow> at <aqua>" + game + "</aqua>! ★</gold>"));
        }
    }
}

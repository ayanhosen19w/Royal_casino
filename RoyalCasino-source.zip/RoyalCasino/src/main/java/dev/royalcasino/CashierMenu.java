package dev.royalcasino;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

final class CashierMenu extends CasinoMenu {

    CashierMenu(RoyalCasino plugin, Player player) {
        super(plugin, player);
        create(27, "<gradient:#ffd700:#ff9d00><bold>♛ Cashier ♛</bold></gradient>");
        fill(Material.BLACK_STAINED_GLASS_PANE);

        inv.setItem(11, Util.item(Material.GOLD_BLOCK, 1, "<gold><bold>Your chips", true,
                "<yellow>" + Util.n(balance()) + " chips",
                "",
                "<gray>Chips are added by the staff.",
                "<gray>Ask an admin if you need more!"));

        List<String> lines = new ArrayList<>();
        int rank = 1;
        for (Map.Entry<UUID, Long> e : plugin.chips().top(5)) {
            lines.add("<gray>" + rank++ + ". <white>" + plugin.chips().name(e.getKey())
                    + " <dark_gray>- <yellow>" + Util.n(e.getValue()));
        }
        if (lines.isEmpty()) lines.add("<gray>Nobody has chips yet.");
        inv.setItem(13, Util.item(Material.NETHER_STAR, 1, "<aqua><bold>Richest players", false,
                lines.toArray(new String[0])));

        inv.setItem(15, Util.item(Material.BOOK, 1, "<green><bold>How to play", false,
                "<gray>Walk up to any table or machine",
                "<gray>and <yellow>right-click</yellow> it to play.",
                "",
                "<gray>Slots has a <light_purple>progressive jackpot<gray>:",
                "<yellow>" + Util.n(plugin.chips().jackpot()) + " chips <gray>right now!",
                "",
                "<gray>Commands: <white>/chips</white>, <white>/chips top</white>"));

        inv.setItem(22, closeItem());
    }

    @Override
    void click(InventoryClickEvent e) {
        if (e.getRawSlot() == 22) player.closeInventory();
    }
}

package dev.royalcasino;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.concurrent.ThreadLocalRandom;

/**
 * 3-reel slot machine, single payline (the middle row).
 * Symbol weights (per reel): cherry 34, lemon 26, bell 20, diamond 13, star 7.
 * Return to player is roughly 93% + 2% progressive jackpot contribution.
 */
final class SlotsMenu extends CasinoMenu {

    private enum Sym {
        CHERRY(Material.SWEET_BERRIES, "<red><bold>Cherry", 34),
        LEMON(Material.YELLOW_DYE, "<yellow><bold>Lemon", 26),
        BELL(Material.BELL, "<gold><bold>Bell", 20),
        DIAMOND(Material.DIAMOND, "<aqua><bold>Diamond", 13),
        STAR(Material.NETHER_STAR, "<light_purple><bold>Lucky Star", 7);

        final Material mat;
        final String name;
        final int weight;

        Sym(Material mat, String name, int weight) {
            this.mat = mat;
            this.name = name;
            this.weight = weight;
        }

        static Sym weighted() {
            int r = ThreadLocalRandom.current().nextInt(100);
            int acc = 0;
            for (Sym s : values()) {
                acc += s.weight;
                if (r < acc) return s;
            }
            return CHERRY;
        }

        static Sym visual() {
            Sym[] v = values();
            return v[ThreadLocalRandom.current().nextInt(v.length)];
        }

        ItemStack stack(boolean glow) {
            return Util.item(mat, 1, name, glow);
        }
    }

    private static final int[] STOP_FRAME = {9, 15, 21};

    private final Sym[][] grid = new Sym[3][3]; // [row][col]
    private boolean busy;
    private int frame;
    private Sym[] result;
    private long pendingWager;
    private long pendingPayout;
    private boolean pendingJackpot;
    private String pendingNote = "";

    SlotsMenu(RoyalCasino plugin, Player player) {
        super(plugin, player);
        create(45, "<gradient:#ffd700:#ff9d00><bold>★ Slot Machine ★</bold></gradient>");
        for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) grid[r][c] = Sym.visual();
        build();
    }

    private static int slotOf(int row, int col) {
        return (row + 1) * 9 + 3 + col;
    }

    private void build() {
        fill(Material.BLACK_STAINED_GLASS_PANE);
        for (int i = 0; i < 45; i++) {
            int row = i / 9, col = i % 9;
            if (row == 0 || row == 4 || col == 0 || col == 8) {
                inv.setItem(i, Util.pane((i % 2 == 0) ? Material.YELLOW_STAINED_GLASS_PANE : Material.ORANGE_STAINED_GLASS_PANE));
            }
        }
        inv.setItem(20, Util.item(Material.REDSTONE_TORCH, "<red><bold>▶ PAYLINE"));
        inv.setItem(24, Util.item(Material.REDSTONE_TORCH, "<red><bold>PAYLINE ◀"));
        inv.setItem(19, paytable());
        render(false);
        refresh();
    }

    private ItemStack paytable() {
        long minJp = plugin.getConfig().getLong("games.slots.jackpot-min-bet", 100L);
        return Util.item(Material.BOOK, 1, "<green><bold>Paytable (middle row)", false,
                "<red>Cherry x3 <gray>- <yellow>6x",
                "<yellow>Lemon x3 <gray>- <yellow>10x",
                "<gold>Bell x3 <gray>- <yellow>20x",
                "<aqua>Diamond x3 <gray>- <yellow>50x",
                "<light_purple>Star x3 <gray>- <yellow>JACKPOT",
                "<dark_gray>  (bet " + Util.n(minJp) + "+ to win it, else 150x)",
                "<red>Any 2 Cherries <gray>- <yellow>bet back");
    }

    private void render(boolean glowMiddle) {
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                inv.setItem(slotOf(r, c), grid[r][c].stack(glowMiddle && r == 1));
            }
        }
    }

    private void refresh() {
        inv.setItem(4, Util.item(Material.NETHER_STAR, 1, "<light_purple><bold>★ JACKPOT ★", true,
                "<yellow>" + Util.n(plugin.chips().jackpot()) + " chips",
                "<gray>Grows with every spin!"));
        inv.setItem(36, balanceItem());
        inv.setItem(38, minusItem());
        inv.setItem(39, betItem());
        inv.setItem(41, plusItem());
        inv.setItem(40, busy
                ? Util.item(Material.GRAY_CONCRETE, "<gray><bold>Spinning...")
                : Util.item(Material.LIME_CONCRETE, 1, "<green><bold>SPIN", true, "<gray>Cost: <yellow>" + Util.n(bet()) + " chips"));
        inv.setItem(44, closeItem());
    }

    @Override
    void click(InventoryClickEvent e) {
        int s = e.getRawSlot();
        if (s == 44) {
            player.closeInventory();
            return;
        }
        if (busy) return;
        switch (s) {
            case 38 -> { if (changeBet(-1)) refresh(); }
            case 41 -> { if (changeBet(1)) refresh(); }
            case 40 -> spin();
            default -> { }
        }
    }

    private void spin() {
        long b = bet();
        if (!take(b)) {
            noFunds();
            return;
        }
        double pct = plugin.getConfig().getDouble("games.slots.jackpot-contribution-percent", 2.0);
        plugin.chips().addJackpot((long) Math.floor(b * pct / 100.0));

        result = new Sym[]{Sym.weighted(), Sym.weighted(), Sym.weighted()};
        pendingWager = b;
        pendingJackpot = false;
        pendingNote = "";
        pendingPayout = evaluate(result, b);

        busy = true;
        frame = 0;
        refresh();
        Util.sound(player, Sound.BLOCK_PISTON_EXTEND, 0.7f, 1.4f);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 2L);
    }

    private long evaluate(Sym[] r, long bet) {
        if (r[0] == r[1] && r[1] == r[2]) {
            return switch (r[0]) {
                case CHERRY -> bet * 6;
                case LEMON -> bet * 10;
                case BELL -> bet * 20;
                case DIAMOND -> bet * 50;
                case STAR -> {
                    long minBet = plugin.getConfig().getLong("games.slots.jackpot-min-bet", 100L);
                    if (bet >= minBet) {
                        long jp = plugin.chips().jackpot();
                        plugin.chips().resetJackpot();
                        pendingJackpot = true;
                        yield jp;
                    }
                    pendingNote = "Bet " + Util.n(minBet) + "+ next time to win the jackpot!";
                    yield bet * 150;
                }
            };
        }
        int cherries = 0;
        for (Sym s : r) if (s == Sym.CHERRY) cherries++;
        return cherries == 2 ? bet : 0;
    }

    private void tick() {
        frame++;
        for (int c = 0; c < 3; c++) {
            if (frame < STOP_FRAME[c]) {
                grid[2][c] = grid[1][c];
                grid[1][c] = grid[0][c];
                grid[0][c] = Sym.visual();
            } else if (frame == STOP_FRAME[c]) {
                grid[0][c] = Sym.visual();
                grid[1][c] = result[c];
                grid[2][c] = Sym.visual();
                Util.sound(player, Sound.BLOCK_NOTE_BLOCK_BELL, 0.8f, 0.8f + 0.25f * c);
            }
        }
        if (frame < STOP_FRAME[2]) Util.sound(player, Sound.BLOCK_NOTE_BLOCK_HAT, 0.35f, 1.2f);
        render(false);
        if (frame >= STOP_FRAME[2]) finishSpin();
    }

    private void finishSpin() {
        if (!busy) return;
        busy = false;
        stopTask();
        for (int c = 0; c < 3; c++) grid[1][c] = result[c];
        give(pendingPayout);

        if (!isClosed()) {
            render(pendingPayout > 0);
            refresh();
        }

        long wager = pendingWager, pay = pendingPayout;
        if (pendingJackpot) {
            Bukkit.broadcast(Util.raw(Util.prefix + "<light_purple><bold>★ JACKPOT! ★ <yellow>" + player.getName()
                    + "</yellow> hit the progressive jackpot for <gold>" + Util.n(pay) + " chips</gold>! ★"));
            Fx.win(plugin, player, "the Slots", wager, pay);
            Fx.firework(player.getLocation().add(0, 1, 0));
            Fx.firework(player.getLocation().add(1, 1, 1));
            Fx.firework(player.getLocation().add(-1, 1, -1));
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        } else if (pay > wager) {
            Util.msg(player, "<green>Slots: <white>" + names() + " <gray>→ <yellow>+" + Util.n(pay - wager) + " chips<gray>.");
            Fx.win(plugin, player, "the Slots", wager, pay);
        } else if (pay == wager && pay > 0) {
            Util.msg(player, "<yellow>Slots: <white>" + names() + " <gray>→ bet returned.");
            Util.sound(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1f);
        } else {
            Util.sound(player, Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.6f);
            Util.msg(player, "<red>Slots: <white>" + names() + " <gray>→ no win.");
        }
        if (!pendingNote.isEmpty()) Util.msg(player, "<gray>" + pendingNote);
    }

    private String names() {
        return result[0].name().toLowerCase() + " | " + result[1].name().toLowerCase() + " | " + result[2].name().toLowerCase();
    }

    @Override
    protected void onClose() {
        if (busy) finishSpin();
    }
}

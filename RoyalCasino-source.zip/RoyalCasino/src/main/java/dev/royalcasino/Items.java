package dev.royalcasino;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

final class Items {
    private Items() {}

    /** The golden block that builds a whole casino when placed. */
    static ItemStack builder(RoyalCasino plugin) {
        ItemStack is = new ItemStack(Material.GOLD_BLOCK);
        ItemMeta m = is.getItemMeta();
        m.displayName(Util.mm("<gradient:#ffd700:#ff9d00><bold>Royal Casino Builder</bold></gradient>"));
        List<Component> lore = List.of(
                Util.mm("<gray>Place this block on open ground"),
                Util.mm("<gray>to build a full casino:"),
                Util.mm("<yellow> • Slots  • Roulette  • Blackjack"),
                Util.mm("<yellow> • Coin Flip  • Lucky Dice  • Cashier"),
                Component.empty(),
                Util.mm("<gold>The entrance faces you and the casino"),
                Util.mm("<gold>grows away from you, in front of the block."),
                Util.mm("<dark_gray>Needs a " + CasinoPlan.W + " x " + CasinoPlan.D + " area (it clears what's inside)."));
        m.lore(lore);
        m.setEnchantmentGlintOverride(true);
        m.getPersistentDataContainer().set(plugin.keyBuilder(), PersistentDataType.BYTE, (byte) 1);
        is.setItemMeta(m);
        return is;
    }

    static boolean isBuilder(RoyalCasino plugin, ItemStack is) {
        if (is == null || !is.hasItemMeta()) return false;
        return is.getItemMeta().getPersistentDataContainer().has(plugin.keyBuilder(), PersistentDataType.BYTE);
    }
}

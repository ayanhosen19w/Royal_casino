package dev.royalcasino;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

final class CasinoListener implements Listener {
    private final RoyalCasino plugin;

    CasinoListener(RoyalCasino plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.chips().ensure(e.getPlayer().getUniqueId(), e.getPlayer().getName());
    }

    // ---------- GUI ----------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof CasinoMenu menu)) return;
        e.setCancelled(true);   // nothing may ever be moved in or out of a casino GUI
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        if (!(e.getWhoClicked() instanceof Player p) || !p.getUniqueId().equals(menu.player().getUniqueId())) return;
        menu.click(e);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof CasinoMenu) e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getInventory().getHolder() instanceof CasinoMenu menu) menu.closed();
    }

    // ---------- stations ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEntityEvent e) {
        Entity ent = e.getRightClicked();
        if (ent.getType() != EntityType.INTERACTION) return;
        String key = ent.getPersistentDataContainer().get(plugin.keyGame(), PersistentDataType.STRING);
        if (key == null) return;
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;
        GameType type = GameType.byKey(key);
        if (type == null) return;
        Player p = e.getPlayer();
        Util.sound(p, Sound.BLOCK_CHEST_OPEN, 0.7f, 1.3f);
        plugin.openGame(p, type);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPunch(EntityDamageByEntityEvent e) {
        Entity ent = e.getEntity();
        if (ent.getType() != EntityType.INTERACTION) return;
        if (ent.getPersistentDataContainer().has(plugin.keyGame(), PersistentDataType.STRING)) e.setCancelled(true);
    }

    // ---------- placing the builder block ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        ItemStack inHand = e.getItemInHand();
        if (e.isCancelled() && !Items.isBuilder(plugin, inHand)) return;   // someone else already denied it

        if (Items.isBuilder(plugin, inHand)) {
            if (e.isCancelled() || !e.canBuild()) return;   // a claim/protection plugin said no
            e.setCancelled(true);   // the block itself never gets placed; the casino does
            if (!p.hasPermission("royalcasino.build")) {
                Util.msg(p, "<red>You don't have permission to build a casino.");
                return;
            }
            Block b = e.getBlockPlaced();
            BlockFace forward = Frame.cardinal(p.getLocation().getYaw());
            String err = BuildJob.start(plugin, p, b.getWorld(), b.getX(), b.getY() - 1, b.getZ(), forward);
            if (err != null) {
                Util.msg(p, err);
                return;
            }
            // Use up one builder block (next tick, so the cancelled placement can't resync the old count over it).
            if (p.getGameMode() != GameMode.CREATIVE) {
                EquipmentSlot hand = e.getHand();
                Bukkit.getScheduler().runTask(plugin, () -> {
                    ItemStack real = p.getInventory().getItem(hand);
                    if (Items.isBuilder(plugin, real)) {
                        real.setAmount(real.getAmount() - 1);
                        p.getInventory().setItem(hand, real.getAmount() > 0 ? real : null);
                    }
                    p.updateInventory();
                });
            }
            return;
        }

        if (protectedFor(p, e.getBlockPlaced().getLocation())) {
            e.setCancelled(true);
            Util.msg(p, "<red>You can't build inside the casino.");
        }
    }

    // ---------- protection ----------

    private boolean protectedFor(Player p, Location l) {
        if (!plugin.getConfig().getBoolean("build.protect-region", true)) return false;
        if (p != null && p.hasPermission("royalcasino.admin")) return false;
        return plugin.regions().at(l) != null;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (protectedFor(e.getPlayer(), e.getBlock().getLocation())) {
            e.setCancelled(true);
            Util.msg(e.getPlayer(), "<red>You can't break blocks inside the casino.");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        if (!plugin.getConfig().getBoolean("build.protect-region", true)) return;
        e.blockList().removeIf(b -> plugin.regions().at(b.getLocation()) != null);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        if (!plugin.getConfig().getBoolean("build.protect-region", true)) return;
        e.blockList().removeIf(b -> plugin.regions().at(b.getLocation()) != null);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (!plugin.getConfig().getBoolean("build.block-mob-spawns", true)) return;
        CreatureSpawnEvent.SpawnReason r = e.getSpawnReason();
        if (r == CreatureSpawnEvent.SpawnReason.NATURAL || r == CreatureSpawnEvent.SpawnReason.REINFORCEMENTS
                || r == CreatureSpawnEvent.SpawnReason.VILLAGE_INVASION || r == CreatureSpawnEvent.SpawnReason.PATROL
                || r == CreatureSpawnEvent.SpawnReason.RAID) {
            if (plugin.regions().at(e.getLocation()) != null) e.setCancelled(true);
        }
    }
}

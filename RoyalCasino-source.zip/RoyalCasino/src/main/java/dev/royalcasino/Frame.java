package dev.royalcasino;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.BlockFace;

/**
 * Maps the casino's local coordinates to the world. The builder block is the front-centre of the entrance plaza
 * (local x = CX, z = 0) and the casino extends "forward", in the direction the player was facing.
 * Local +x is the player's LEFT, local +z is forward; that is a proper rotation, so directional blocks just rotate.
 */
record Frame(World world, int ox, int oy, int oz, int fx, int fz, int lx, int lz, int turns) {

    private static final BlockFace[] ORDER = {BlockFace.NORTH, BlockFace.EAST, BlockFace.SOUTH, BlockFace.WEST};

    /** @param forward the cardinal direction the casino extends in (the way the player looked when placing). */
    static Frame of(World w, int x, int y, int z, BlockFace forward) {
        return switch (forward) {
            case WEST -> new Frame(w, x, y, z, -1, 0, 0, 1, 1);
            case NORTH -> new Frame(w, x, y, z, 0, -1, -1, 0, 2);
            case EAST -> new Frame(w, x, y, z, 1, 0, 0, -1, 3);
            default -> new Frame(w, x, y, z, 0, 1, 1, 0, 0);   // SOUTH
        };
    }

    /** Cardinal direction from a yaw angle (Minecraft convention: 0 = south, 90 = west, 180 = north, 270 = east). */
    static BlockFace cardinal(float yaw) {
        float y = ((yaw % 360) + 360) % 360;
        if (y >= 315 || y < 45) return BlockFace.SOUTH;
        if (y < 135) return BlockFace.WEST;
        if (y < 225) return BlockFace.NORTH;
        return BlockFace.EAST;
    }

    int wx(int x, int z) {
        return ox + lx * (x - CasinoPlan.CX) + fx * z;
    }

    int wz(int x, int z) {
        return oz + lz * (x - CasinoPlan.CX) + fz * z;
    }

    /** Continuous local point -> world location (px/pz are in "block" units where block x spans [x, x+1]). */
    Location loc(double px, double y, double pz) {
        double x = ox + 0.5 + lx * (px - CasinoPlan.CX - 0.5) + fx * (pz - 0.5);
        double z = oz + 0.5 + lz * (px - CasinoPlan.CX - 0.5) + fz * (pz - 0.5);
        return new Location(world, x, y, z);
    }

    BlockFace rot(BlockFace f) {
        for (int i = 0; i < 4; i++) if (ORDER[i] == f) return ORDER[(i + turns) % 4];
        return f;
    }
}

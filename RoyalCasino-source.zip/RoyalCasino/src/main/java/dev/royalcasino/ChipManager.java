package dev.royalcasino;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.*;

/** Chip balances + the progressive slots jackpot. Persisted to balances.yml. */
final class ChipManager {
    static final long MAX = 1_000_000_000_000_000L;

    private final RoyalCasino plugin;
    private final File file;
    private final Map<UUID, Long> chips = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private long jackpot;
    private boolean dirty;

    ChipManager(RoyalCasino plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "balances.yml");
    }

    private long seed() {
        return plugin.getConfig().getLong("games.slots.jackpot-seed", 1000L);
    }

    void load() {
        chips.clear();
        names.clear();
        jackpot = seed();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        jackpot = Math.max(seed(), y.getLong("jackpot", seed()));
        ConfigurationSection sec = y.getConfigurationSection("players");
        if (sec == null) return;
        for (String k : sec.getKeys(false)) {
            try {
                UUID id = UUID.fromString(k);
                chips.put(id, Math.max(0L, sec.getLong(k + ".chips")));
                String nm = sec.getString(k + ".name");
                if (nm != null) names.put(id, nm);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    void save() {
        if (!dirty) return;
        YamlConfiguration y = new YamlConfiguration();
        y.set("jackpot", jackpot);
        for (Map.Entry<UUID, Long> e : chips.entrySet()) {
            y.set("players." + e.getKey() + ".chips", e.getValue());
            String nm = names.get(e.getKey());
            if (nm != null) y.set("players." + e.getKey() + ".name", nm);
        }
        try {
            plugin.getDataFolder().mkdirs();
            File tmp = new File(plugin.getDataFolder(), "balances.yml.tmp");
            y.save(tmp);
            Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().severe("Could not save balances.yml: " + ex.getMessage());
        }
    }

    /** Called on join: remembers the name, gives starting chips the first time. */
    void ensure(UUID id, String name) {
        names.put(id, name);
        if (!chips.containsKey(id)) {
            chips.put(id, Math.max(0L, plugin.getConfig().getLong("economy.starting-chips", 0L)));
        }
        dirty = true;
    }

    long get(UUID id) {
        return chips.getOrDefault(id, 0L);
    }

    long add(UUID id, long amount) {
        long n = Math.min(MAX, get(id) + Math.max(0L, amount));
        chips.put(id, n);
        dirty = true;
        return n;
    }

    /** Atomically removes chips. Returns false (and changes nothing) if the player can't afford it. */
    boolean take(UUID id, long amount) {
        if (amount < 0) return false;
        long cur = get(id);
        if (cur < amount) return false;
        chips.put(id, cur - amount);
        dirty = true;
        return true;
    }

    void set(UUID id, long value) {
        chips.put(id, Math.max(0L, Math.min(MAX, value)));
        dirty = true;
    }

    String name(UUID id) {
        return names.getOrDefault(id, id.toString().substring(0, 8));
    }

    UUID find(String name) {
        for (Map.Entry<UUID, String> e : names.entrySet()) {
            if (e.getValue().equalsIgnoreCase(name)) return e.getKey();
        }
        return null;
    }

    List<String> knownNames() {
        return new ArrayList<>(names.values());
    }

    List<Map.Entry<UUID, Long>> top(int n) {
        List<Map.Entry<UUID, Long>> all = new ArrayList<>(chips.entrySet());
        all.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
        return all.subList(0, Math.min(n, all.size()));
    }

    long jackpot() {
        return Math.max(jackpot, seed());
    }

    void addJackpot(long amount) {
        if (amount <= 0) return;
        jackpot = Math.min(MAX, jackpot() + amount);
        dirty = true;
    }

    void resetJackpot() {
        jackpot = seed();
        dirty = true;
    }
}

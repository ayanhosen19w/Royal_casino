package dev.royalcasino;

import org.bukkit.Location;

/** Axis-aligned bounding box (inclusive block coordinates) of one built casino. y0 is the floor level. */
record CasinoRegion(String id, String world, int minX, int minY, int minZ, int maxX, int maxY, int maxZ, int y0) {

    boolean contains(Location l) {
        return l.getWorld() != null && l.getWorld().getName().equals(world)
                && l.getBlockX() >= minX && l.getBlockX() <= maxX
                && l.getBlockY() >= minY && l.getBlockY() <= maxY
                && l.getBlockZ() >= minZ && l.getBlockZ() <= maxZ;
    }

    boolean overlaps(String w, int x1, int y1, int z1, int x2, int y2, int z2) {
        return world.equals(w)
                && x1 <= maxX && x2 >= minX
                && y1 <= maxY && y2 >= minY
                && z1 <= maxZ && z2 >= minZ;
    }
}

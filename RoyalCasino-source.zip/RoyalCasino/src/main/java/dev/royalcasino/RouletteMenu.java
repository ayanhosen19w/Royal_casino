package dev.royalcasino;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/** European (single-zero) roulette with a scrolling wheel. 2.7% house edge. One bet per spin. */
final class RouletteMenu extends CasinoMenu {

    private static final int[] WHEEL = {0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5,
            24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26};
    private static final Set<Integer> REDS = Set.of(1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36);

    private enum Bet {
        RED("Red", 2), BLACK("Black", 2), ODD("Odd", 2), EVEN("Even", 2), LOW("1-18", 2), HIGH("19-36", 2),
        DOZ1("1st dozen (1-12)", 3), DOZ2("2nd dozen (13-24)", 3), DOZ3("3rd dozen (25-36)", 3),
        NUMBER("Straight number", 36);

        final String label;
        final int total; // total chips returned per chip staked on a win

        Bet(String label, int total) {
            this.label = label;
            this.total = total;
        }
    }

    private Bet pick = Bet.RED;
    private int number = 17;
    private boolean busy;
    private int pos = ThreadLocalRandom.current().nextInt(37); // index into WHEEL shown in the centre
    private int stepsLeft;
    private int result;
    private long pendingWager;
    private long pendingPayout;
    private final Deque<Integer> history = new ArrayDeque<>();

    RouletteMenu(RoyalCasino plugin, Player player) {
        super(plugin, player);
        create(54, "<gradient:#ffd700:#ff9d00><bold>◉ Roulette ◉</bold></gradient>");
        fill(Material.BLACK_STAINED_GLASS_PANE);
        for (int i = 0; i < 54; i++) {
            int row = i / 9, col = i % 9;
            if (row == 0 || col == 0 || col == 8) {
                inv.setItem(i, Util.pane((i % 2 == 0) ? Material.YELLOW_STAINED_GLASS_PANE : Material.ORANGE_STAINED_GLASS_PANE));
            }
        }
        inv.setItem(22, Util.item(Material.HOPPER, "<yellow><bold>▼ Winning pocket ▼"));
        renderAll();
    }

    private static boolean isRed(int n) {
        return REDS.contains(n);
    }

    private static Material colorMat(int n) {
        return n == 0 ? Material.GREEN_CONCRETE : isRed(n) ? Material.RED_CONCRETE : Material.BLACK_CONCRETE;
    }

    private static String colorTag(int n) {
        return n == 0 ? "<green>" : isRed(n) ? "<red>" : "<white>";
    }

    private static ItemStack pocket(int n, boolean glow) {
        return Util.item(colorMat(n), n == 0 ? 1 : n, colorTag(n) + "<bold>" + n, glow);
    }

    private boolean wins(Bet b, int n) {
        return switch (b) {
            case RED -> n != 0 && isRed(n);
            case BLACK -> n != 0 && !isRed(n);
            case ODD -> n != 0 && n % 2 == 1;
            case EVEN -> n != 0 && n % 2 == 0;
            case LOW -> n >= 1 && n <= 18;
            case HIGH -> n >= 19 && n <= 36;
            case DOZ1 -> n >= 1 && n <= 12;
            case DOZ2 -> n >= 13 && n <= 24;
            case DOZ3 -> n >= 25 && n <= 36;
            case NUMBER -> n == number;
        };
    }

    private ItemStack choice(Bet b, Material m, String name) {
        boolean sel = pick == b;
        return Util.item(m, 1, name, sel, "<gray>Pays <yellow>" + (b.total - 1) + ":1",
                sel ? "<green>● Selected" : "<dark_gray>Click to select");
    }

    private void renderAll() {
        inv.setItem(10, choice(Bet.RED, Material.RED_CONCRETE, "<red><bold>RED"));
        inv.setItem(11, choice(Bet.BLACK, Material.BLACK_CONCRETE, "<white><bold>BLACK"));
        inv.setItem(12, choice(Bet.ODD, Material.CYAN_CONCRETE, "<aqua><bold>ODD"));
        inv.setItem(13, choice(Bet.EVEN, Material.BLUE_CONCRETE, "<blue><bold>EVEN"));
        inv.setItem(14, choice(Bet.LOW, Material.LIME_CONCRETE, "<green><bold>1-18"));
        inv.setItem(15, choice(Bet.HIGH, Material.ORANGE_CONCRETE, "<gold><bold>19-36"));
        inv.setItem(16, Util.item(Material.GREEN_CONCRETE, 1, "<green><bold>ZERO", pick == Bet.NUMBER && number == 0,
                "<gray>Pays <yellow>35:1", (pick == Bet.NUMBER && number == 0) ? "<green>● Selected" : "<dark_gray>Click to select"));
        inv.setItem(19, choice(Bet.DOZ1, Material.PINK_CONCRETE, "<light_purple><bold>1st 12"));
        inv.setItem(20, choice(Bet.DOZ2, Material.MAGENTA_CONCRETE, "<light_purple><bold>2nd 12"));
        inv.setItem(21, choice(Bet.DOZ3, Material.PURPLE_CONCRETE, "<light_purple><bold>3rd 12"));
        inv.setItem(23, Util.item(Material.ARROW, "<gray>◀ Number -1", "<dark_gray>Shift-click: -5"));
        boolean numSel = pick == Bet.NUMBER && number != 0;
        inv.setItem(24, Util.item(colorMat(number), 1, "<yellow><bold>Straight: " + colorTag(number) + number, numSel,
                "<gray>Pays <yellow>35:1", numSel ? "<green>● Selected" : "<dark_gray>Click to select"));
        inv.setItem(25, Util.item(Material.ARROW, "<gray>Number +1 ▶", "<dark_gray>Shift-click: +5"));
        renderStrip();
        renderHistory();
        inv.setItem(45, balanceItem());
        inv.setItem(46, minusItem());
        inv.setItem(47, betItem());
        inv.setItem(48, plusItem());
        inv.setItem(49, busy
                ? Util.item(Material.GRAY_CONCRETE, "<gray><bold>Spinning...")
                : Util.item(Material.LIME_CONCRETE, 1, "<green><bold>SPIN", true, "<gray>Cost: <yellow>" + Util.n(bet()) + " chips"));
        String what = pick == Bet.NUMBER ? "Number " + number : pick.label;
        inv.setItem(51, Util.item(Material.PAPER, 1, "<yellow><bold>Your bet", false,
                "<white>" + what, "<gray>Pays <yellow>" + (pick.total - 1) + ":1"));
        inv.setItem(53, closeItem());
    }

    private void renderStrip() {
        for (int k = -4; k <= 4; k++) {
            int n = WHEEL[Math.floorMod(pos + k, 37)];
            inv.setItem(31 + k, pocket(n, k == 0 && !busy));
        }
    }

    private void renderHistory() {
        int i = 0;
        for (int n : history) {
            inv.setItem(36 + i, pocket(n, false));
            i++;
        }
        for (; i < 9; i++) inv.setItem(36 + i, Util.pane(Material.GRAY_STAINED_GLASS_PANE));
    }

    @Override
    void click(InventoryClickEvent e) {
        int s = e.getRawSlot();
        if (s == 53) {
            player.closeInventory();
            return;
        }
        if (busy) return;
        switch (s) {
            case 10 -> select(Bet.RED);
            case 11 -> select(Bet.BLACK);
            case 12 -> select(Bet.ODD);
            case 13 -> select(Bet.EVEN);
            case 14 -> select(Bet.LOW);
            case 15 -> select(Bet.HIGH);
            case 16 -> { number = 0; select(Bet.NUMBER); }
            case 19 -> select(Bet.DOZ1);
            case 20 -> select(Bet.DOZ2);
            case 21 -> select(Bet.DOZ3);
            case 23 -> { number = Math.floorMod(number - (e.isShiftClick() ? 5 : 1), 37); select(Bet.NUMBER); }
            case 25 -> { number = Math.floorMod(number + (e.isShiftClick() ? 5 : 1), 37); select(Bet.NUMBER); }
            case 24 -> select(Bet.NUMBER);
            case 46 -> { if (changeBet(-1)) renderAll(); }
            case 48 -> { if (changeBet(1)) renderAll(); }
            case 49 -> spin();
            default -> { }
        }
    }

    private void select(Bet b) {
        pick = b;
        Util.sound(player, Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
        renderAll();
    }

    private void spin() {
        long b = bet();
        if (!take(b)) {
            noFunds();
            return;
        }
        pendingWager = b;
        result = ThreadLocalRandom.current().nextInt(37);
        pendingPayout = wins(pick, result) ? b * pick.total : 0L;

        int target = 0;
        for (int i = 0; i < WHEEL.length; i++) if (WHEEL[i] == result) target = i;
        stepsLeft = 37 + Math.floorMod(target - pos, 37);
        busy = true;
        renderAll();
        Util.sound(player, Sound.BLOCK_PISTON_EXTEND, 0.6f, 1.2f);
        schedule();
    }

    private void schedule() {
        int delay = stepsLeft > 12 ? 1 : stepsLeft > 6 ? 2 : stepsLeft > 2 ? 3 : 5;
        task = Bukkit.getScheduler().runTaskLater(plugin, this::step, delay);
    }

    private void step() {
        pos = (pos + 1) % 37;
        stepsLeft--;
        renderStrip();
        Util.sound(player, Sound.BLOCK_NOTE_BLOCK_HAT, 0.5f, 1.0f + (stepsLeft < 8 ? 0.2f : 0f));
        if (stepsLeft <= 0) finish();
        else schedule();
    }

    private void finish() {
        if (!busy) return;
        busy = false;
        stopTask();
        for (int i = 0; i < WHEEL.length; i++) if (WHEEL[i] == result) pos = i;
        give(pendingPayout);
        history.addFirst(result);
        while (history.size() > 9) history.removeLast();
        if (!isClosed()) renderAll();

        String ball = colorTag(result) + "<bold>" + result;
        if (pendingPayout > pendingWager) {
            Util.msg(player, "<green>Roulette: the ball landed on " + ball + "<green>! <yellow>+"
                    + Util.n(pendingPayout - pendingWager) + " chips<gray>.");
            Fx.win(plugin, player, "Roulette", pendingWager, pendingPayout);
        } else {
            Util.msg(player, "<red>Roulette: the ball landed on " + ball + "<red>. <gray>No win.");
            Util.sound(player, Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.6f);
        }
    }

    @Override
    protected void onClose() {
        if (busy) finish();
    }
}

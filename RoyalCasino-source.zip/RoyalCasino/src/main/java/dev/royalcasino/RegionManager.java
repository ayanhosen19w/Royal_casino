package dev.royalcasino;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

/** Remembers where casinos were built (for protection, removal, and "am I in a casino?"). */
final class RegionManager {
    private final RoyalCasino plugin;
    private final File file;
    private final Map<String, CasinoRegion> regions = new LinkedHashMap<>();

    RegionManager(RoyalCasino plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "casinos.yml");
    }

    void load() {
        regions.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = y.getConfigurationSection("casinos");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            ConfigurationSection c = sec.getConfigurationSection(id);
            if (c == null) continue;
            regions.put(id, new CasinoRegion(id, c.getString("world", "world"),
                    c.getInt("minX"), c.getInt("minY"), c.getInt("minZ"),
                    c.getInt("maxX"), c.getInt("maxY"), c.getInt("maxZ"), c.getInt("floorY", c.getInt("minY"))));
        }
    }

    void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (CasinoRegion r : regions.values()) {
            String p = "casinos." + r.id() + ".";
            y.set(p + "world", r.world());
            y.set(p + "minX", r.minX());
            y.set(p + "minY", r.minY());
            y.set(p + "minZ", r.minZ());
            y.set(p + "maxX", r.maxX());
            y.set(p + "maxY", r.maxY());
            y.set(p + "maxZ", r.maxZ());
            y.set(p + "floorY", r.y0());
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save casinos.yml: " + e.getMessage());
        }
    }

    void add(CasinoRegion r) {
        regions.put(r.id(), r);
        save();
    }

    void remove(String id) {
        regions.remove(id);
        save();
    }

    Collection<CasinoRegion> all() {
        return regions.values();
    }

    CasinoRegion at(Location l) {
        for (CasinoRegion r : regions.values()) if (r.contains(l)) return r;
        return null;
    }

    boolean overlaps(String world, int x1, int y1, int z1, int x2, int y2, int z2) {
        for (CasinoRegion r : regions.values()) if (r.overlaps(world, x1, y1, z1, x2, y2, z2)) return true;
        return false;
    }
}
